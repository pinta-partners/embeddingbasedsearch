# Chassidus Chat Application: Goals and Coding Outline

## Project Goals

1. Create a chat application with an LLM backend focused on Jewish Chassidus knowledge.
2. Use OpenAI's GPT-4 (gpt-4o-2024-08-06) for chat responses and text-embedding-3-small for embeddings.
3. Implement a system to import, translate, and embed Chassidus texts from JSON files.
4. Provide responses based on the Chassidus knowledge base, maintaining the appropriate style and flavor.
5. Allow for incremental updates to the knowledge base without full reimports.
6. Enable both vector similarity and tag-based searching of the knowledge base.
7. Include references to original Hebrew sources via Sefaria links.

## Coding Outline

1. Project Setup
   - Initialize SvelteKit project
   - Set up Supabase project
   - Configure Vercel for deployment

2. Database Schema (Supabase)
   - Create `chassidus_texts` table with necessary columns

3. Data Import System (To be implemented)
   - Create `import_chassidus.sh` shell script
   - Implement JSON parsing function
   - Develop translation function (if automatic translation is needed)
   - Create embedding generation function using OpenAI's API
   - Implement Sefaria link generation function
   - Develop database upsert function

4. Backend API Routes (SvelteKit)
   - `/api/embed`: Handle embedding generation (Implemented)
   - `/api/chat`: Process chat requests and interact with GPT-4 (Implemented)
   - `/api/search`: Implement vector and tag-based search (To be implemented)
   - `/api/import`: Secure endpoint to trigger data imports (To be implemented)

5. Frontend Components (Svelte)
   - ChatInterface.svelte: Main chat UI (Implemented)
   - MessageList.svelte: Display chat history (Implemented as part of ChatInterface)
   - InputBox.svelte: Handle user input (Implemented as part of ChatInterface)
   - StreamingResponse.svelte: Display AI responses (To be implemented)
   - SourceReference.svelte: Show Sefaria links and metadata (To be implemented)

6. Integration and API Handling
   - Implement OpenAI API calls for chat and embeddings (Implemented)
   - Set up Supabase client for database interactions (Implemented)
   - Configure Vercel AI SDK for response streaming (To be implemented)

7. Search and Retrieval Logic
   - Implement vector similarity search
   - Develop tag-based search functionality
   - Create logic to combine and rank search results

8. User Interface Enhancements
   - Add filters for tag-based searching
   - Implement display of source references and Sefaria links

9. Security and Optimization
   - Implement rate limiting on API routes
   - Set up proper authentication and authorization
   - Optimize database queries and implement caching where appropriate

10. Testing and Deployment
    - Write unit tests for critical functions
    - Perform integration testing
    - Set up CI/CD pipeline with Vercel
    - Deploy application

11. Documentation
    - Create user guide
    - Document API endpoints
    - Provide instructions for data imports and updates

12. Maintenance and Iteration
    - Plan for regular updates to the knowledge base
    - Monitor performance and user feedback
    - Iterate on features and UI based on usage patterns

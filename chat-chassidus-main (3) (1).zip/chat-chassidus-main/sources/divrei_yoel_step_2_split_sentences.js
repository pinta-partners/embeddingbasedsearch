import dotenv from '../dotenv.js';
import pg from 'pg';

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

function splitIntoSentences(text) {
  console.log('\n=== Paragraph ===');
  console.log(`Length: ${text.length} characters`);
  console.log(text);
  
  // Split on periods, question marks, exclamation points, citations, and Hebrew connectors
  let split = text.split(/(?<=[.!?])\s+|,\s+(?=ומעתה|וע"כ|ועתה|והנה|ולכן|אבל|ומ"מ|ועי"ז|אמנם|וכן|והוא|ועוד|וא"כ|עכ"פ|עיי"ש|עייש"ד)|(?<=\))\s+(?=[א-ת])/);
  split = split.map(s => s.trim()).filter(s => s.length > 0);

  // Additional splits for very long sentences
  split = split.flatMap(s => {
    if (s.length > 800) {
      // First try splitting on strong break points including citations and section markers
      let subSplit = s.split(/,\s+(?=טעם\s|והטעם\s|ועל\s*כן\s|ולכן\s|אמנם\s|איתא\s|ופי'\s|ופירשו\s)|(?<=:)\s+(?=[א-ת])/g);
      
      // If we still have very long segments, split on vav-prefixed words and parenthetical endings
      subSplit = subSplit.flatMap(ss => {
        if (ss.length > 800) {
          return ss.split(/,\s+(?=ו[ה|מ|ע|ל|ג|ז|ש])|(?<=\))\s+(?=[א-ת])|(?<=עיי"ש|עייש"ד|ע"כ)\s+(?=[א-ת])/g);
        }
        return ss;
      });
      
      return subSplit.filter(s => s.length > 0);
    }
    return s;
  });

  // Handle segments that are too short for meaningful embedding
  split = split.reduce((result, current, index, array) => {
    // If this is the first item and it's short, combine it with the next item
    if (index === 0 && current.length < 100 && array.length > 1) {
      result.push(current + ' ' + array[1]);
      return result;
    }
    
    // Skip the second item if we combined it with the first
    if (index === 1 && result.length > 0 && result[0].includes(current)) {
      return result;
    }
    
    // For other items, try to merge short ones intelligently
    if (current.length < 100 && index > 0) {
      // Check if combining would create an overly long segment
      const combined = result[result.length - 1] + ' ' + current;
      if (combined.length <= 400) {
        result[result.length - 1] = combined;
        return result;
      }
    }
    
    // Don't create very short final segments
    if (index === array.length - 1 && current.length < 100 && result.length > 0) {
      console.log(`Merging final segment: "${current}" with previous`);
      result[result.length - 1] += ' ' + current;
      return result;
    }
    
    console.log(`Adding segment ${index + 1}: "${current.substring(0, 50)}..."`);
    result.push(current);
    return result;
  }, []);

  console.log('\n=== Split Sentences ===');
  split.forEach((s, i) => {
    console.log(`${i + 1}. [${s.length} chars] ${s}`);
    console.log('---'); // Separator between sentences for clarity
  });
  console.log(`Total sentences: ${split.length}`);
  return split;
}

async function processChassidustexts() {
  const client = await pool.connect();
  let batchCount = 0;
  try {
    while (true) {
      batchCount++;
      console.log(`\nProcessing batch ${batchCount}...`);
      // Process in batches
      const result = await client.query(
        `SELECT id, text, context, paragraph, source, tags, sefaria_name
         FROM chassidus_texts 
         WHERE id NOT IN (SELECT DISTINCT chassidus_text_id FROM chassidus_sentences where source='Divrei Yoel')
         AND source = 'Divrei Yoel'
		 AND tags @> '{Vayishlach}'
         LIMIT 50`
      );

      if (result.rows.length === 0) {
        console.log('No more texts to process');
        break;
      }

      for (const text of result.rows) {
        console.log(`Processing text ID: ${text.id}`);
        const originalText = text.text;
        const originalLength = originalText.length;
        const sentences = splitIntoSentences(originalText);

        // Insert sentences in batch
        const values = sentences.map((sentence, index) => {
          const value = {
          sentence_length: sentence.length,
          chassidus_text_id: text.id,
          sentence,
          sentence_number: index + 1,
          paragraph: text.paragraph,
          source: text.source,
          tags: text.tags,
          sefaria_name: text.sefaria_name
          };
          return value;
        });

        // Use a single query to insert all sentences
        const placeholders = values.map((_, i) => 
          `($${i * 7 + 1}, $${i * 7 + 2}, $${i * 7 + 3}, $${i * 7 + 4}, $${i * 7 + 5}, $${i * 7 + 6}, $${i * 7 + 7})`
        ).join(',');

        const flatValues = values.flatMap(v => [
          v.chassidus_text_id,
          v.sentence,
          v.sentence_number,
          v.paragraph,
          v.source,
          v.tags,
          v.sefaria_name
        ]);

        await client.query(
          `INSERT INTO chassidus_sentences 
           (chassidus_text_id, sentence, sentence_number, paragraph, source, tags, sefaria_name)
           VALUES ${placeholders}`,
          flatValues
        );

        console.log(`Inserted ${sentences.length} sentences for text ID ${text.id}`);
      }
    }
  } catch (error) {
    console.error('Error in main process:', error);
  } finally {
    client.release();
  }
}

processChassidustexts().catch(console.error);

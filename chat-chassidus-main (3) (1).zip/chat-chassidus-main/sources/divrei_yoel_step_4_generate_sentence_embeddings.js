import dotenv from '../dotenv.js';
import { OpenAI } from 'openai';
import pLimit from 'p-limit';
import pg from 'pg';

// Shutdown handling
let shutdownRequested = false;
let forceShutdown = false;

process.on('SIGINT', () => {
  if (shutdownRequested) {
    console.log('\nForce shutting down...');
    forceShutdown = true;
    process.exit(1);
  } else {
    console.log('\nGraceful shutdown requested. Will stop after current batch. Press Ctrl+C again to force stop.');
    shutdownRequested = true;
  }
});

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

// OpenAI configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Limit concurrent API calls
const limit = pLimit(50);

// Timeout for API calls (in milliseconds)
const API_TIMEOUT = 40000;

async function generateEmbeddingsBatch(sentences) {
  try {
    const combinedTexts = sentences.map(s => 
      `${s.translation}\n\n${s.sentence}`.trim()
    );

    const startTime = Date.now();
    const response = await Promise.race([
      openai.embeddings.create({
        model: "text-embedding-3-large",
        input: combinedTexts,
      }),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('OpenAI API timeout (large)')), API_TIMEOUT)
      )
    ]);
    const endTime = Date.now();

    if((endTime - startTime) > 10000) {
      console.log(`Batch embedding generation took ${endTime - startTime}ms for ${sentences.length} sentences`);
    }

    return sentences.map((sentence, i) => ({
      id: sentence.id,
      embedding_large: response.data[i].embedding
    }));
  } catch (error) {
    console.error(`Error generating embeddings for translation: "${translation.substring(0, 50)}..."`, error);
    return null;
  }
}

async function updateEmbeddingsBatch(client, embeddings) {
  try {
    const startTime = Date.now();
    
    // Prepare batch update parameters
    const values = embeddings.map((e, i) => 
      `($${i*2 + 1}::uuid, $${i*2 + 2}::vector)`
    ).join(',');
    
    const params = embeddings.flatMap(e => [
      e.id,
      JSON.stringify(e.embedding_large)
    ]);

    await client.query(`
      UPDATE chassidus_sentences AS cs
      SET embedding_large_english_hebrew = c.embedding
      FROM (VALUES ${values}) AS c(id, embedding)
      WHERE cs.id = c.id
    `, params);
    
    const endTime = Date.now();
    if((endTime - startTime) > 5000) {
      console.log(`Batch embedding update took ${endTime - startTime}ms for ${embeddings.length} sentences`);
    }
  } catch (error) {
    console.error('Error updating embeddings batch:', error);
    console.error('Error details:', error.message);
    if (error.detail) console.error('Error detail:', error.detail);
    if (error.hint) console.error('Error hint:', error.hint);
  }
}

async function processSentences() {
  let count = 0;
  let totalCount = 0;
  const batchSizeSQL = 500;
  const batchSizeEmbedding = 50;

  while (!shutdownRequested && !forceShutdown) {
    const client = await pool.connect();
    try {
      const startTime = Date.now();
      const result = await client.query(`
        SELECT id, translation, sentence
        FROM chassidus_sentences
        WHERE embedding_large_english_hebrew IS NULL 
        AND translation IS NOT NULL
        LIMIT $1
      `, [batchSizeSQL]);
      const sentences = result.rows;
      const endTime = Date.now();

      console.log(`Fetching sentences took ${endTime - startTime}ms`);

      if (sentences.length === 0) {
        console.log('No more sentences to process.');
        break;
      }

      console.log(`Processing ${sentences.length} sentences`);

      // Process in smaller chunks for API limits
      for (let i = 0; i < sentences.length; i += batchSizeEmbedding) {
		if(shutdownRequested) return;
        const chunk = sentences.slice(i, i + batchSizeEmbedding);
        const embeddings = await generateEmbeddingsBatch(chunk);
        if (embeddings && embeddings.length > 0) {
          await updateEmbeddingsBatch(client, embeddings);
          count += chunk.length;
          totalCount += chunk.length;
          console.log(new Date().toISOString().split('T')[1] + 
            `: Processed ${count} sentences in this batch, ${totalCount} total`);
        }
      }
    } catch (error) {
      console.error('Error in processing batch:', error);
      // Wait for a short time before retrying
      await new Promise(resolve => setTimeout(resolve, 5000));
    } finally {
      client.release();
    }
  }

  if (shutdownRequested) {
    console.log(`\nGracefully stopped after processing ${totalCount} sentences.`);
  } else {
    console.log(`\nFinished processing ${totalCount} sentences.`);
  }
}

processSentences().catch(console.error);

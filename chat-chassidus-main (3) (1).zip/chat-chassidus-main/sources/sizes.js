const {readdir, readFile} = require('fs/promises');

async function run(){
	//log the list of files
	const list = await readdir('./');
	console.log(list);

	//for each JSON file, open it up and iterate the 'text' key.
	//Iterate down until we get to an array, and tell me the breadcumb tree, how many lines, and the total number of characters

	//   "text": {
    //    "on Torah": {
    //        "Bereshit": [
	for (let file of list) {
		console.log('checking ',file);
		if(!file.endsWith('.json')) continue;
		if(file=='sizes.js') continue;

		var fileTotalChars = 0;
		var categories = [];

		const data = JSON.parse(await readFile(file, 'utf8'));
		const keys = Object.keys(data.text);
		for (let key of keys) {
			const subKeys = Object.keys(data.text[key]);
			for (let subKey of subKeys) {
				let lines = data.text[key][subKey];
				if(Array.isArray(lines[0])) {
					console.warn('found array of arrays in',key,subKey);
					//flatten the array
					let newLines = [];
					for (let line of lines) {
						newLines = newLines.concat(line);
						}
					lines = newLines;
					}
				let totalChars = 0;
				for (let line of lines) {
					totalChars += line.length;
					fileTotalChars += line.length;
				}
				categories.push(totalChars.toString().padStart(6,'0') + ' ' + key + ' -> ' + subKey);
				console.log(`${key} -> ${subKey}: ${lines.length} lines, ${totalChars} characters`);
			}
		}
		categories.sort();
		categories.reverse();
		console.log(categories);
		console.log(file,'total characters:',fileTotalChars.toLocaleString());
	}
}

run();
import dotenv from '../dotenv.js';
import pg from 'pg';
import fs from 'fs/promises';
import path from 'path';
import pLimit from 'p-limit';

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

async function parseTranslationFile(content) {
  // Split content into sections using a simpler approach
  const translationMatch = content.match(/(?:\*\*Translation\*\*:|\*\*English Translation\*\*:|Translation:|English Translation:)([\s\S]*?)(?=Summary:|$)/i);
  const summaryMatch = content.match(/Summary:([\s\S]*?)(?=(?:Keywords:|10 Keywords:)|$)/i);
  const keywordsMatch = content.match(/(?:Keywords:|10 Keywords:)([\s\S]*?)$/i);

  let translation = translationMatch ? translationMatch[1].trim().replace(/^\*\*\s*|\s*\*\*$/g, '') : '';
  let summary = summaryMatch ? summaryMatch[1].trim().replace(/^\*\*\s*|\s*\*\*$/g, '') : '';
  let keywords = [];
  let errors = [];

  // Process keywords if found
  if (keywordsMatch) {
    // Split at the Hebrew passage marker and take only the first part
    const keywordText = keywordsMatch[1].split(/[\n\r]*\*\*Original Hebrew Passage\*\*/)[0];
    keywords = keywordText
      .split('\n')
      .map(k => k.replace(/^\d+\.\s*/, '').trim().replace(/^\*\*\s*|\s*\*\*$/g, ''))
      .filter(k => k && k !== '---' && k.length > 1); // Filter out dashes and very short entries
  }

  // Check for missing sections
  if (!translation) errors.push('Missing English Translation section');
  if (!summary) errors.push('Missing Summary section');
  if (keywords.length === 0) errors.push('Missing Keywords section');

  // Additional validation
  if (translation && !/[a-zA-Z]/.test(translation)) {
    errors.push('Translation contains no English text');
  }
  if (summary && !/[a-zA-Z]/.test(summary)) {
    errors.push('Summary contains no English text');
  }

  // Check translation length ratio
  const hebrewMatch = content.match(/\*\*Original Hebrew Passage\*\*:([\s\S]*?)(?=(?:\*\*English Translation:|Translation:)|$)/i);
  if (hebrewMatch) {
    const hebrewText = hebrewMatch[1].trim();
    
    // If Hebrew text is very short, skip all validation
    if (hebrewText.length < 50) {
      throw new Error('very short, skipping import: ' + hebrewText.length);
    }
    
    const translationLengthRatio = translation.length / hebrewText.length;
    if (translationLengthRatio > 3) {
      errors.push(`Translation is suspiciously long (${translationLengthRatio.toFixed(1)}x longer than Hebrew text)`);
    }
  }

  if (errors.length > 0) {
    throw new Error('File validation failed:\n- ' + errors.join('\n- '));
  }

  return { translation, summary, keywords };
}

function extractSefariaRef(filename) {
  // Remove the _idx_XXX suffix and .txt extension
  const base = filename.replace(/_idx_\d+\.txt$/, '');
  
  // Split the filename into parts
  const parts = base.split('_');
  
  // Handle the book name
  let sefariaRef = 'Tiferet_Shlomo,_';
  
  // Handle the section (on Torah/on Festivals)
  if (parts[1] === 'onFestivals') {
    sefariaRef += 'on_Festivals,_';
  } else if (parts[1] === 'onTorah') {
    sefariaRef += 'on_Torah,_';
  }
  
  // Handle special cases for nested references
  if (parts[2].startsWith('PirkeiAvot')) {
    // Extract number from the part
    const number = parts[2].match(/\d+$/);
	const numbers = number[0].split('');
    // Always format as chapter.verse
    sefariaRef += `Pirkei_Avot.${numbers[0]}.${numbers[1]}`;
  } else {
    // Handle regular references
    // Remove any trailing numbers that might be part numbers
    let mainSection = parts[2].replace(/\d+$/, '');
    
    // Special case for BirkatHaTorah
    if (mainSection === 'BirkatHaTorah') mainSection = 'Birkat_HaTorah';
	else if(mainSection==="SefiratHaOmer") mainSection="Sefirat_HaOmer";
	else if (mainSection ==="ShabbatHaGadol") mainSection="Shabbat_HaGadol";
	else if(mainSection==="ParashatHaChodesh") mainSection="Parashat_HaChodesh";
	else if(mainSection==="LagBaOmer") mainSection="Lag_BaOmer";
	
	else if(mainSection==="HaAzinu") mainSection ="Ha'Azinu";
	else if(mainSection==="Behaalotcha") mainSection="Beha'alotcha";
	else if(mainSection==="Reeh") mainSection="Re'eh";
	else if(mainSection==="Shlach") mainSection = "Sh'lach";
	else if(mainSection==="Tisha BAv") mainSection = "Tisha B'Av";
	else if(mainSection==="VZot HaBerachah") mainSection = "V'Zot HaBerachah";
    else {
      // Add underscores between mixed case words
      mainSection = mainSection.replace(/([a-z])([A-Z])/g, '$1_$2');
    }
    
    sefariaRef += mainSection;
    
    // Add any specific subsection number if present
    if (parts[2].match(/\d+$/)) {
      sefariaRef += '.' + parts[2].match(/\d+$/)[0];
    }
  }
  
  return sefariaRef;
}

async function updateDatabase(client, sefariaRef, data, filename) {
  try {
    const { translation, summary, keywords } = data;
    
    // First query to check existing record
    const checkResult = await client.query(
      `SELECT id, sefaria_name FROM chassidus_texts WHERE sefaria_name = $1`,
      [sefariaRef]
    );

    if (checkResult.rows.length === 0) {
      const error = `No matching record found for: ${sefariaRef}\nOriginal filename: ${filename}`;
      console.log(error);
      
      // Try to find similar references for debugging
      const similarResult = await client.query(
        `SELECT sefaria_name FROM chassidus_texts 
         WHERE sefaria_name ILIKE $1 LIMIT 5`,
        [`%${sefariaRef.split(',')[2].trim()}%`]
      );
      if (similarResult.rows.length > 0) {
        console.log('Similar references found:');
        similarResult.rows.forEach(row => console.log('- ' + row.sefaria_ref));
      }
      
      // Copy the file to failed_imports directory
      const sourcePath = path.join(process.cwd(), 'sources', 'translation import', filename);
      const destPath = path.join(process.cwd(), 'sources', 'failed_imports', filename);
      await fs.copyFile(sourcePath, destPath);
      
      throw new Error(error);
    } else {
      const result = await client.query(
        `UPDATE chassidus_texts 
         SET translation_version = 5,
             translation = $1, 
             summary = $2, 
             keywords = $3 
         WHERE sefaria_name = $4 
         RETURNING id`,
        [translation, summary, keywords, sefariaRef]
      );
      //console.log(`Updated record ${result.rows[0].id} for: ${sefariaRef}`);
    }
  } catch (error) {
    console.error(`Error updating database for ${sefariaRef}:`, error);
  }
}

async function processTranslationFiles() {
  const client = await pool.connect();
  const reviewFilePath = path.join(process.cwd(), 'sources', 'manual_review_needed.txt');
  const failedImportsDir = path.join(process.cwd(), 'sources', 'failed_imports');
  let reviewContent = '';
  
  try {
    // Create failed imports directory if it doesn't exist
    await fs.mkdir(failedImportsDir, { recursive: true });

    const translationsDir = path.join(process.cwd(), 'sources', 'translation import');
    const files = await fs.readdir(translationsDir);
    
    // Set up concurrent processing with p-limit
    const limit = pLimit(30); // Process 5 files concurrently
    const promises = files
      .filter(file => file.endsWith('.txt'))
	  .filter(file=>file.includes('PirkeiAvot'))
      .map(file => limit(async () => {
        //console.log(`Processing ${file}...`);
        
        try {
          const filePath = path.join(translationsDir, file);
          const content = await fs.readFile(filePath, 'utf8');
          const sefariaRef = extractSefariaRef(file);
          const data = await parseTranslationFile(content);
          
          await updateDatabase(client, sefariaRef, data, file);
        } catch (error) {
          console.log(`⚠️ File needs manual review: ${file}`);
          console.log(`   Reason: ${error.message}`);
          reviewContent += `File: ${file}\nReason: ${error.message}\n\n`;
          
          // Copy failed file to failed_imports directory
          const sourcePath = path.join(translationsDir, file);
          const destPath = path.join(failedImportsDir, file);
          await fs.copyFile(sourcePath, destPath);
        }
      }));

    await Promise.all(promises);

    if (reviewContent) {
      await fs.writeFile(reviewFilePath, reviewContent);
      console.log(`\nFiles needing manual review have been logged to: manual_review_needed.txt`);
      console.log(`Failed files have been copied to: ${failedImportsDir}`);
    }
    console.log('\nFinished processing all translation files');
  } catch (error) {
    console.error('Error processing translation files:', error);
  } finally {
    client.release();
  }
}

processTranslationFiles().catch(console.error);

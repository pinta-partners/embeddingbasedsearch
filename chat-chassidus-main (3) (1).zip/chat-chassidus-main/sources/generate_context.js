import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import { OpenAI } from 'openai';
import pLimit from 'p-limit';

// Load environment variables
dotenv.config({ path: '../.env', debug: true });

// Supabase configuration
const supabaseUrl = process.env.PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.PUBLIC_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// OpenAI configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Limit concurrent API calls
const limit = pLimit(20);

async function generateContext(wholeDocument, chunk) {
  const prompt = `<document>
${wholeDocument}
</document>
Here is the chunk we want to situate within the whole document
<chunk>
${chunk}
</chunk>
Please give a short succinct context to situate this chunk within the overall document for the purposes of improving search retrieval of the chunk. Answer only with the succinct context and nothing else.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [{ role: "user", content: prompt }],
      temperature: 0.4,
      max_tokens: 100,
    });
    return response.choices[0].message.content.trim();
  } catch (error) {
    console.error('Error generating context:', error);
    return null;
  }
}

async function updateContext(id, context) {
  const { error } = await supabase
    .from('chassidus_texts')
    .update({ context })
    .eq('id', id);

  if (error) {
    console.error('Error updating context:', error);
  }
}

async function processTexts() {
  let count = 0;
  let { data: texts, error } = await supabase
    .from('chassidus_texts')
    .select('id, text, tags')
    .is('context', null);

  if (error) {
    console.error('Error fetching texts:', error);
    return;
  }

  console.log(`Found ${texts.length} texts without context.`);

  // Group texts by tags
  const groupedTexts = texts.reduce((acc, text) => {
    const key = text.tags.sort().join(',');
    if (!acc[key]) acc[key] = [];
    acc[key].push(text);
    return acc;
  }, {});

  for (const [tags, group] of Object.entries(groupedTexts)) {
    const wholeDocument = group.map(t => t.text).join('\n\n');

    const promises = group.map(text => limit(async () => {
      const context = await generateContext(wholeDocument, text.text);
      if (context) {
        await updateContext(text.id, context);
        count++;
        if (count % 10 === 0) {
          console.log(`Processed ${count} texts`);
        }
      }
    }));

    await Promise.all(promises);
  }

  console.log(`Finished processing ${count} texts.`);
}

processTexts().catch(console.error);

import dotenv from 'dotenv';
import { OpenAI } from 'openai';
import pLimit from 'p-limit';
import pg from 'pg';

const TRANSLATION_VERSION = 1;

// Load environment variables
dotenv.config({ path: '../.env', debug: true });

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

// OpenAI configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Limit concurrent API calls
const limit = pLimit(150);

function trimQuotes(text){
	return text.trim().replace(/^"/,'').replace(/"$/,'');
}

async function translate(context, section) {
	const prompt = `<context>
  ${context}
  </context>
  Given this context, please translate the following section from the Chassidic Sefer "Tiferes Shlomo" into English. Only reply with a translation - no introduction or explanation:
  <section>
  ${section}
  </section>`;
  //console.log(prompt)
	try {
		const timeoutPromise = new Promise((_, reject) =>
		setTimeout(() => reject(new Error('OpenAI API request timed out')), 25000)
		);

		const apiRequestPromise = openai.chat.completions.create({
			model: "gpt-4o-mini",
			messages: [{ role: "user", content: prompt }],
			temperature: 0.3,
			max_tokens: section.length, //limit it to the number of hebrew letters - must be shorter than that!
			});

	 const response = await Promise.race([apiRequestPromise, timeoutPromise]);

	  const result = trimQuotes(response.choices[0].message.content);
	  //console.log(context, section, result);
	  console.log('RESULT:',result);
	  return result;
	} catch (error) {
	  console.error('Error generating context:', error);
	  return null;
	}
}
  

async function processTexts() {
  const client = await pool.connect();
  try {
    const result = await client.query(`
      SELECT cs.id, cs.sentence, ct.context
      FROM chassidus_sentences cs
      JOIN chassidus_texts ct ON cs.chassidus_text_id = ct.id
      WHERE cs.translation_version IS NULL
      LIMIT 500
    `);
    const texts = result.rows;

    console.log(`Found ${texts.length} texts without translation.`);

    if (texts.length === 0) {
      console.log('No more texts to translate. Exiting.');
      return;
    }
	console.time(`Processing ${texts.length} texts....`)
	//console.log(texts);
    const translationPromises = texts.map(text => limit(() => translateAndSave(text)));
    await Promise.all(translationPromises);

    console.timeEnd(`Processing ${texts.length} texts....`)

    // Recursively call processTexts to fetch and process more documents
    await processTexts();
  } finally {
    client.release();
  }
}

async function translateAndSave(text) {
  const translation = await translate(text.context, text.sentence);
  if (translation) {
    const client = await pool.connect();
    try {
		//console.log('UPDATE chassidus_sentences SET translation = $1, translation_version = $2 WHERE id = $3',
        //[translation, TRANSLATION_VERSION, text.id]);

      await client.query(
        'UPDATE chassidus_sentences SET translation = $1, translation_version = $2 WHERE id = $3',
        [translation, TRANSLATION_VERSION, text.id]
      );
      //console.log(`Translation saved for text ID: ${text.id}`);
    } catch (error) {
      console.error('Error saving translation:', error);
    } finally {
      client.release();
    }
  }
}

processTexts().catch(console.error);


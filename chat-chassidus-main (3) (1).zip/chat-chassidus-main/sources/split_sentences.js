import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import pLimit from 'p-limit';

// Load environment variables
dotenv.config({ path: '../.env', debug: true });

// Supabase configuration
const supabaseUrl = process.env.PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.PUBLIC_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// OpenAI configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Limit concurrent API calls
const limit = pLimit(30);

function splitIntoSentences(text) {
	//split on 30 characters or more, followed by a period, question mark, or exclamation point
	let split = text.split(/[.?!] /g);
	split = split.map(s=>s.trim());

	//if the last split is less than 30 characters, merge it with the previous split
	split = split.reduce(function(result, current, index) {
		if (current.length < 30 && index > 0) {
			result[result.length - 1] += ' ' + current;
			return result
			}
		else {
			result.push(current)
			return result;
			}
		}, []);

	return split;
}

async function generateEmbedding(text) {
  try {
    const response = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: text,
    });
    return response.data[0].embedding;
  } catch (error) {
    console.error('Error generating embedding:', error);
    return null;
  }
}

async function flush_buffer(insert_buffer) {
	if(!insert_buffer || insert_buffer.length === 0) return;
	const { error: insertError } = await supabase
          .from('chassidus_sentences')
          .insert(insert_buffer);
		  if (insertError) {
			console.error('Error inserting sentences:', insertError)
			process.exit(1);
		  	}
	}
	


async function processChassidustexts() {
  let count = 0;
  let { data: texts, error } = await supabase
    .from('chassidus_texts')
    .select('id, text, context, paragraph, source, tags, sefaria_name')
	.eq('source', 'Tiferet Shlomo')
	.limit(3000);

  if (error) {
    console.error('Error fetching texts:', error);
    return;
  }

  console.log(`Found ${texts.length} texts to process.`);
  let insert_buffer = [];

  for (const text of texts) {
    const sentences = splitIntoSentences(text.text);
	for (let [index, sentence] of sentences.entries()) {

      /*const [embeddingSentence, embeddingSentenceWithContext] = await Promise.all([
        generateEmbedding(sentence),
        generateEmbedding(`${text.context || ''}\n\n${sentence}`.trim())
      ]);*/

      //if (embeddingSentence && embeddingSentenceWithContext) {
    insert_buffer.push({
            chassidus_text_id: text.id,
            sentence,
			sentence_number: index+1,
            //context: text.context,
            paragraph: text.paragraph,
            //embedding_sentence: embeddingSentence,
            //embedding_sentence_with_context: embeddingSentenceWithContext,
            source: text.source,
            tags: text.tags,
            sefaria_name: text.sefaria_name
          });

        //if (insertError) {
          //console.error('Error inserting sentence:', insertError);
        //} else {
          count++;
          if (count % 100 === 0) {
            console.log(`Processed ${count} sentences`);
          //}
        }
      //}
    }

	if (insert_buffer.length >= 500) {
		await flush_buffer(insert_buffer);
		insert_buffer = [];
		}
  }

  await flush_buffer(insert_buffer);
  console.log(`Finished processing ${count} sentences.`);
}

processChassidustexts().catch(console.error);

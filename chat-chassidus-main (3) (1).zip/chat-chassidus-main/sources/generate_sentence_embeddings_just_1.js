import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import pLimit from 'p-limit';

// Load environment variables
dotenv.config({ path: '../.env', debug: true });

// Supabase configuration
const supabaseUrl = process.env.PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.PUBLIC_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// OpenAI configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Limit concurrent API calls
const limit = pLimit(50);

// Timeout for API calls (in milliseconds)
const API_TIMEOUT = 30000;

async function generateEmbeddings(sentences, contexts) {
  try {
    const input = sentences.map((sentence, index) => 
      `${contexts[index] || ''}\n\n${sentence}`.trim()
    );

    const startTime = Date.now();
    const response = await Promise.race([
      openai.embeddings.create({
        model: "text-embedding-3-large",
        input: input,
      }),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('OpenAI API timeout')), API_TIMEOUT)
      )
    ]);
    const endTime = Date.now();

    console.log(`Embedding generation took ${endTime - startTime}ms for ${sentences.length} sentences`);

    return response.data.map(item => item.embedding.slice(0,1536)); //shorten it for storage
  } catch (error) {
    console.error(`Error generating embeddings for batch`, error);
    return null;
  }
}



async function updateEmbeddings(data) {
  const startTime = Date.now();
  
  const updatePromises = data.map(sentence => 
    limit(() => updateSingleEmbedding(sentence))
  );

  try {
    await Promise.all(updatePromises);
    const endTime = Date.now();
    console.log(`Embedding update took ${endTime - startTime}ms for ${data.length} sentences`);
  } catch (error) {
    console.error(`Error updating embeddings for batch`, error);
  }
}

async function updateSingleEmbedding(sentence) {
  try {
	//console.log(sentence);
	//console.log(sentence.id,sentence.embedding.slice(0,5));
    const { error } = await Promise.race([
      supabase
        .from('chassidus_sentences')
        .update({embedding_sentence: sentence.embedding_sentence})
		.eq('id',sentence.id)
		,
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Supabase update timeout')), API_TIMEOUT)
      )
    ]);

    if (error) {
      console.error(`Error updating embedding for sentence`, error);
    }
  } catch (error) {
    console.error(`Timeout or error updating embedding for sentence`, error);
  }
}

async function processSentences() {
  let count = 0;
  const batchSize = 600;

  while (true) {
    try {
      const startTime = Date.now();
      const { data: sentences, error } = await Promise.race([
        supabase
          .from('chassidus_sentences')
          .select(`
            id, 
            sentence, 
            chassidus_texts (context)
          `)
          .is('embedding_sentence', null)
          .limit(batchSize),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Supabase fetch timeout')), API_TIMEOUT)
        )
      ]);
      const endTime = Date.now();

      console.log(`Fetching sentences took ${endTime - startTime}ms`);

      if (error) {
        console.error('Error fetching sentences:', error);
        break;
      }

      if (!sentences || sentences.length === 0) {
        console.log('No more sentences to process.');
        break;
      }

      console.log(`Processing ${sentences.length} sentences`);

      const sentenceTexts = sentences.map(s => s.sentence);
      const contexts = sentences.map(s => s.chassidus_texts ? s.chassidus_texts.context : null);
      const embeddings = await generateEmbeddings(sentenceTexts, contexts);

      if (embeddings) {
		const updates = sentences.map((s, i) => ({ id: s.id, embedding_sentence: embeddings[i] }))
        await updateEmbeddings(updates);
        count += sentences.length;
        console.log(new Date().toISOString().split('T')[1] + `: Processed ${count} sentences`);
      }

    } catch (error) {
      console.error('Error in processing batch:', error);
      // Wait for a short time before retrying
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }

  console.log(`Finished processing ${count} sentences.`);
}

processSentences().catch(console.error);

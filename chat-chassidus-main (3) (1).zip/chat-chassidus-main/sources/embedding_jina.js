import https from 'https';
import dotenv from '../dotenv.js';

export async function embedding(task = 'retrieval.passage', input) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify({
      "model": "jina-embeddings-v3",
      "task": task,
      "dimensions": 1024,
      "late_chunking": false,
      "embedding_type": "float",
      "input": input
    });

    const options = {
      hostname: 'api.jina.ai',
      port: 443,
      path: '/v1/embeddings',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(data),
		'Authorization': 'Bearer ' + process.env.JINA_API_KEY
      }
    };

    const req = https.request(options, (res) => {
      let responseBody = '';

      res.on('data', (chunk) => {
        responseBody += chunk;
      });

      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          var data = JSON.parse(responseBody);
		  if(task=='retrieval.query' && typeof input == 'string'){

			resolve(data.data[0].embedding);
		  	}
		else resolve(data);
        } else {
          reject({
            status: res.statusCode,
            statusText: res.statusMessage
          });
        }
      });
    });

    req.on('error', (error) => {
      reject({
        status: null,
        statusText: error.message
      });
    });

    req.write(data);
    req.end();
  });
}

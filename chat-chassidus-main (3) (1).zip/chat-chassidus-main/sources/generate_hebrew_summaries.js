import dotenv from '../dotenv.js';
import pg from 'pg';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

async function generateHebrewSummary(text) {
  try {
    const message = await anthropic.messages.create({
      model: "claude-3-opus-20240229",
      max_tokens: 1000,
      temperature: 0.3,
      system: "You are an expert in Jewish texts and Hebrew language. Your task is to create concise summaries in Hebrew of Jewish texts.",
      messages: [{
        role: "user",
        content: `Please create a concise summary (2-3 sentences) in Hebrew of the following text. Use modern Hebrew with nikkud:

${text}

Respond with ONLY the Hebrew summary, nothing else.`
      }]
    });
    
    return message.content[0].text;
  } catch (error) {
    console.error('Error generating Hebrew summary:', error);
    throw error;
  }
}

async function updateHebrewSummary(client, id, summary) {
  try {
    await client.query(
      `UPDATE chassidus_texts 
       SET summary_hebrew = $1
       WHERE id = $2`,
      [summary, id]
    );
  } catch (error) {
    console.error(`Error updating Hebrew summary for ID ${id}:`, error);
    throw error;
  }
}

async function processTexts() {
  const client = await pool.connect();
  try {
    while (true) {
      // Process in batches to avoid memory issues
      const result = await client.query(
        `SELECT id, text 
         FROM chassidus_texts 
         WHERE summary_hebrew IS NULL 
         LIMIT 10`
      );

      if (result.rows.length === 0) {
        console.log('No more texts to process');
        break;
      }

      for (const row of result.rows) {
        try {
          console.log(`Processing ID ${row.id}...`);
          const hebrewSummary = await generateHebrewSummary(row.text);
          await updateHebrewSummary(client, row.id, hebrewSummary);
          console.log(`Updated ID ${row.id}`);
          
          // Add a small delay to avoid rate limiting
          await new Promise(resolve => setTimeout(resolve, 1000));
        } catch (error) {
          console.error(`Failed to process ID ${row.id}:`, error);
          continue;
        }
      }
    }
  } finally {
    client.release();
  }
}

processTexts().catch(console.error);

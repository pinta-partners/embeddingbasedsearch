import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import pLimit from 'p-limit';

// Load environment variables
dotenv.config({ path: '../.env', debug: true });

// Supabase configuration
const supabaseUrl = process.env.PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.PUBLIC_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// OpenAI configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Limit concurrent API calls
const limit = pLimit(30);

async function generateEmbedding(text, context, sefaria_name) {
  try {
	let input = `${context || ''}\n\n${text}`.trim();
	if(input.length>8191) console.log(sefaria_name ,"is too long", input.length)
    const response = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: input,
    });
    return response.data[0].embedding;
  } catch (error) {
    console.error('Error generating embedding:', error);
    return null;
  }
}

async function updateEmbedding(id, embedding) {
  const { error } = await supabase
    .from('chassidus_texts')
    .update({ embedding_context: embedding })
    .eq('id', id);

  if (error) {
    console.error('Error updating embedding:', error);
  }
}

async function processTexts() {
  let count = 0;
  let { data: texts, error } = await supabase
    .from('chassidus_texts')
    .select('id, text, context, sefaria_name')
    .is('embedding_context', null)
	//and context is set
	.not('context', 'is', null);

  if (error) {
    console.error('Error fetching texts:', error);
    return;
  }

  console.log(`Found ${texts.length} texts without embeddings.`);

  const promises = texts.map(text => limit(async () => {
    const embedding = await generateEmbedding(text.text, text.context, text.sefaria_name);
    if (embedding) {
      await updateEmbedding(text.id, embedding);
      count++;
      if (count % 100 === 0) {
        console.log(`Processed ${count} texts`);
      }
    }
  }));

  await Promise.all(promises);
  console.log(`Finished processing ${count} texts.`);
}

processTexts().catch(console.error);

console.time('Execution time');
import dotenv from '../dotenv.js';
import pg from 'pg';
import { createObjectCsvWriter } from 'csv-writer';
import fs from 'fs/promises';
import path from 'path';
import mammoth from 'mammoth';


const SECTIONS = [
	{ parsha: 'Introduction', parsha_hebrew: 'הקדמה', position: 1 },
	{ parsha: 'Bereishis', parsha_hebrew: 'בראשית', position: 2 },
	{ parsha: 'Noach', parsha_hebrew: 'נח', position: 3 },
	{ parsha: 'Lech Lecha', parsha_hebrew: 'לך לך', position: 4 },
	{ parsha: 'Vayera', parsha_hebrew: 'וירא', position: 5 },
	{ parsha: 'Chayei Sarah', parsha_hebrew: 'חיי שרה', position: 6 },
	{ parsha: 'Toldos', parsha_hebrew: 'תולדות', position: 7 }
];
const volume = 'Volume 1';
const volume_hebrew = 'חלק ראשון';

const source = 'Divrei Yoel';
const source_hebrew = 'דברי יואל';

// Parse command line arguments
const args = process.argv.slice(2);
const REAL_MODE = args.includes('--real');

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

async function parseTextFile(filePath) {
  try {
    // Read DOCX file
    const fileContents = await fs.readFile(filePath,{encoding:'utf8'});

	console.log(fileContents)
    //const result = await mammoth.extractRawText({ buffer });
    //const content = result.value;
    
    // Split on #### to get major sections
    const sections = fileContents.split(/####/).map(p => p.trim()).filter(p => p.length > 0);
    
	console.log(JSON.stringify(sections[1].slice(0,50000)));

    console.log('\nFound sections:', sections.length);
    sections.forEach((section, idx) => {
		console.log('\n' + '='.repeat(50));
		const MatchesTitle = section.startsWith(SECTIONS[idx].parsha_hebrew);
		console.log(`Section ${idx + 1}: ` + (MatchesTitle ? '✓':'x') + ' ' + SECTIONS[idx].parsha_hebrew);

		sections[idx] = sections[idx].replace(SECTIONS[idx].parsha_hebrew,'');//remove the parsha title from the first entry
	

	  console.log(SECTIONS[idx].parsha_hebrew,section.substring(0, 50)+'...')
      // Right-to-left mark and formatting for Hebrew
      //console.log('First Paragraph: \u200F' + paragraphs[0].substring(0, 150) + '...');
	  //console.log('Second paragraph: \u200F' + paragraphs[1].substring(0, 150) + '...');
    });

	

    // Process each section into paragraphs
    const structuredData = sections.map((section, index) => {
      // Split section into paragraphs
      const paragraphs = section.split(/\n\s*\n/).map(p => p.trim()).filter(p => p.length > 0);
      // Split into sub-paragraphs (split on double newlines)
      const subParagraphs = section
        .split(/\n+/)
        .map(sp => sp.trim())
        .filter(sp => sp.length > 0);

		

      return {
        paragraph_number: index + 1,
        full_text: section,
        character_length: section.length,
        sub_paragraphs: subParagraphs,
        sub_paragraph_count: subParagraphs.length
      };
    });

    return structuredData;
  } catch (error) {
    console.error('Error reading or parsing file:', error);
    throw error;
  }
}

async function writeToCSV(paragraphs, info) {
  const csvWriter = createObjectCsvWriter({
    path: 'output_texts.csv',
    header: [
      {id: 'text', title: 'TEXT'},
      {id: 'tags', title: 'TAGS'},
      {id: 'source', title: 'SOURCE'},
      {id: 'paragraph', title: 'PARAGRAPH'},
      {id: 'name_pretty', title: 'NAME_PRETTY'},
      {id: 'name_pretty_hebrew', title: 'NAME_PRETTY_HEBREW'},
      {id: 'volume', title: 'VOLUME'},
      {id: 'position', title: 'POSITION'}
    ],
    append: true
  });

  const records = [];
  
  for (const para of paragraphs) {
    for (let i = 0; i < para.sub_paragraphs.length; i++) {
      records.push({
        text: para.sub_paragraphs[i],
        tags: JSON.stringify([info.parsha, info.parsha_hebrew, info.volume, info.volume_hebrew]),
        source: info.source,
        paragraph: `${i + 1}`,
        name_pretty: `${info.source} - ${info.parsha}`,
        name_pretty_hebrew: `${info.source_hebrew} - ${info.parsha_hebrew}`,
        volume: info.volume,
        position: info.position
      });
    }
  }

  try {
    await csvWriter.writeRecords(records);
    console.log(`Wrote ${records.length} records to CSV`);
  } catch (error) {
    console.error('Error writing to CSV:', error);
  }
}



async function main() {
  let client;
  try {
    if (REAL_MODE) {
      client = await pool.connect();
    }
    const filePath = path.join(process.cwd(), 'sources', 'divrei yoel', 'divreiyoel1.txt');
    
    // Base info for all sections
    const baseInfo = {
      source,
      source_hebrew,
      volume,
      volume_hebrew
    };

    const parsedData = await parseTextFile(filePath);
    
    /*console.log('\nFile Structure Analysis:');
    console.log(`Total paragraphs: ${parsedData.length}`);
    console.log('\nFirst few characters of each major section:');
    parsedData.slice(0, 10).forEach((para, i) => {
      console.log(`\nSection ${i + 1}:`);
      console.log(para.full_text.substring(0, 100) + '...');
    });*/

    console.log('\nGenerating CSV output file...');
    // Delete existing CSV if it exists
    try {
      await fs.unlink('output_texts.csv');
    } catch (error) {
      // Ignore error if file doesn't exist
    }
    
    for (const section of SECTIONS) {
      const info = {
        ...baseInfo,
        ...section
      };
      const sectionData = parsedData[section.position - 1];
      if (sectionData) {
        await writeToCSV([sectionData], info);
        console.log(`Processed section: ${section.parsha}`);
      }
    }
    console.log('CSV file generated as output_texts.csv');
    
    // Print summary
    console.log('\nSummary:');
    console.log(`Total sections found: ${parsedData.length}`);
    console.log('\nSection sizes:');
    parsedData.forEach((para, index) => {
      console.log(`Section ${para.paragraph_number}: ${para.sub_paragraph_count} paragraphs, ${Math.round(para.character_length / 1000)}K chars`);
    });

    console.log('Processing complete!');
	console.timeEnd('Execution time');
    process.exit();

  } catch (error) {
    console.error('Error in main:', error);
  } finally {
    if (client) {
      await client.end();
    }
    if (REAL_MODE) {
      await pool.end();
    }
  }
}

main().catch(console.error);

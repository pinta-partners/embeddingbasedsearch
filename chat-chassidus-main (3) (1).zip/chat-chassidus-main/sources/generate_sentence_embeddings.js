import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import OpenAI from 'openai';
import pLimit from 'p-limit';

// Load environment variables
dotenv.config({ path: '../.env', debug: true });

// Supabase configuration
const supabaseUrl = process.env.PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.PUBLIC_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

// OpenAI configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Limit concurrent API calls
const limit = pLimit(50);

// Timeout for API calls (in milliseconds)
const API_TIMEOUT = 10000;

async function generateEmbeddings(sentence, context) {
  try {
    const input = [
      sentence,
      `${context || ''}\n\n${sentence}`.trim()
    ];

    const startTime = Date.now();
    const response = await Promise.race([
      openai.embeddings.create({
        model: "text-embedding-3-small",
        input: input,
      }),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('OpenAI API timeout')), API_TIMEOUT)
      )
    ]);
    const endTime = Date.now();

    if((endTime - startTime) > 5000) console.log(`Embedding generation took ${endTime - startTime}ms for sentence: "${sentence.substring(0, 50)}..."`);

    return {
      embedding_sentence: response.data[0].embedding,
      embedding_sentence_with_context: response.data[1].embedding
    };
  } catch (error) {
    console.error(`Error generating embeddings for sentence: "${sentence.substring(0, 50)}..."`, error);
    return null;
  }
}

async function updateEmbeddings(id, embeddings) {
  try {
    const startTime = Date.now();
    const { error } = await Promise.race([
      supabase
        .from('chassidus_sentences')
        .update(embeddings)
        .eq('id', id),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Supabase update timeout')), API_TIMEOUT)
      )
    ]);
    const endTime = Date.now();

    if((endTime - startTime)>5000) console.log(`Embedding update took ${endTime - startTime}ms for id: ${id}`);

    if (error) {
      console.error(`Error updating embeddings for id: ${id}`, error);
    }
  } catch (error) {
    console.error(`Timeout or error updating embeddings for id: ${id}`, error);
  }
}

async function processSentences() {
  let count = 0;
  const batchSize = 300;

  while (true) {
    try {
      const startTime = Date.now();
      const { data: sentences, error } = await Promise.race([
        supabase
          .from('chassidus_sentences')
          .select(`
            id, 
            sentence, 
            chassidus_texts (context)
          `)
          .is('embedding_sentence', null)
          .is('embedding_sentence_with_context', null)
          .limit(batchSize),
        new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Supabase fetch timeout')), API_TIMEOUT)
        )
      ]);
      const endTime = Date.now();

      console.log(`Fetching sentences took ${endTime - startTime}ms`);

      if (error) {
        console.error('Error fetching sentences:', error);
        break;
      }

      if (!sentences || sentences.length === 0) {
        console.log('No more sentences to process.');
        break;
      }

      console.log(`Processing ${sentences.length} sentences`);

      const promises = sentences.map(sentence => limit(async () => {
        const context = sentence.chassidus_texts ? sentence.chassidus_texts.context : null;
        const embeddings = await generateEmbeddings(sentence.sentence, context);
        if (embeddings) {
          await updateEmbeddings(sentence.id, embeddings);
          count++;
          if (count % 20 === 0) {
			//timestamp it:
            console.log(new Date().toISOString().split('T')[1] + `: Processed ${count} sentences`);
          }
        }
      }));

      await Promise.all(promises);
    } catch (error) {
      console.error('Error in processing batch:', error);
      // Wait for a short time before retrying
      await new Promise(resolve => setTimeout(resolve, 5000));
    }
  }

  console.log(`Finished processing ${count} sentences.`);
}

processSentences().catch(console.error);

import dotenv from '../dotenv.js';
import pLimit from 'p-limit';
import pg from 'pg';
import { embedding } from './embedding_jina.js';

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

// Limit concurrent API calls
const limit = pLimit(10);
//500 RPM & 1,000,000 TPM

// Timeout for API calls (in milliseconds)
const API_TIMEOUT = 25000;

async function generateEmbeddings(translation, context, sentence) {
  try {
    const input = [
      `${context || ''}\n\n${translation}\n\n${sentence}`.trim()
    ];

    const startTime = Date.now();
    const response = await Promise.race([
      embedding('retrieval.passage', input),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('Jina API timeout')), API_TIMEOUT)
      )
    ]);
    const endTime = Date.now();

    if((endTime - startTime) > 10000) console.log(`Embedding generation took ${endTime - startTime}ms for translation: "${translation.substring(0, 50)}..."`);

    return {
      embedding_jina_context_english: response.data[0].embedding
    };
  } catch (error) {
    console.error(`Error generating embeddings for translation: "${translation.substring(0, 50)}..."`, error);
    return null;
  }
}

async function batchUpdateEmbeddings(client, updates) {
  try {
    const startTime = Date.now();
    const values = updates.map((update, i) => `($${i*2 + 1}::vector, $${i*2 + 2})`).join(',');
    const params = updates.flatMap(update => [
      JSON.stringify(update.embeddings.embedding_jina_context_english),
      update.id
    ]);
    
    await client.query(
      `UPDATE chassidus_sentences AS cs SET 
       embedding_jina_context_english = v.embedding
       FROM (VALUES ${values}) AS v(embedding, id)
       WHERE cs.id = v.id::uuid`,
      params
    );
    
    const endTime = Date.now();
    if((endTime - startTime) > 5000) {
      console.log(`Batch embedding update took ${endTime - startTime}ms for ${updates.length} records`);
    }
  } catch (error) {
    console.error('Error in batch update:', error);
    console.error('Error details:', error.message);
    if (error.detail) console.error('Error detail:', error.detail);
    if (error.hint) console.error('Error hint:', error.hint);
  }
}

async function processSentences() {
  let count = 0;
  let totalCount = 0;
  const batchSize = 500;

  while (true) {
    const client = await pool.connect();
    try {
      const startTime = Date.now();
      const result = await client.query(`
        SELECT cs.id, cs.translation, cs.sentence, ct.context
        FROM chassidus_sentences cs
        JOIN chassidus_texts ct ON cs.chassidus_text_id = ct.id
        WHERE cs.embedding_jina_context_english IS NULL 
        AND cs.translation IS NOT NULL
        LIMIT $1
      `, [batchSize]);
      const sentences = result.rows;
      const endTime = Date.now();

      console.log(`Fetching sentences took ${endTime - startTime}ms`);

      if (sentences.length === 0) {
        console.log('No more sentences to process.');
        break;
      }

      console.log(`Processing ${sentences.length} sentences`);

      // Generate all embeddings first
      const embeddingPromises = sentences.map(sentence => limit(async () => {
        const embeddings = await generateEmbeddings(sentence.translation, sentence.context, sentence.sentence);
        return embeddings ? { id: sentence.id, embeddings } : null;
      }));

      const results = (await Promise.all(embeddingPromises)).filter(r => r !== null);
      
      // Batch update in groups of 50
      const updateBatchSize = 50;
      for (let i = 0; i < results.length; i += updateBatchSize) {
        const batch = results.slice(i, i + updateBatchSize);
        await batchUpdateEmbeddings(client, batch);
        count += batch.length;
        totalCount += batch.length;
        console.log(new Date().toISOString().split('T')[1] + 
          `: Processed ${batch.length} sentences in this batch, ${totalCount} total`);
      }
    } catch (error) {
      console.error('Error in processing batch:', error);
      // Wait for a short time before retrying
      await new Promise(resolve => setTimeout(resolve, 5000));
    } finally {
      client.release();
    }
  }

  console.log(`Finished processing ${totalCount} sentences.`);
}

processSentences().catch(console.error);

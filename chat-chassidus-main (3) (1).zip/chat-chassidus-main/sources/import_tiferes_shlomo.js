import fs  from 'fs/promises';
import { createClient } from '@supabase/supabase-js';


// Supabase configuration
import dotenv from 'dotenv';
dotenv.config({path: '../.env', debug:true});
const supabaseUrl = process.env.PUBLIC_SUPABASE_URL;
const supabaseKey = process.env.PUBLIC_SUPABASE_ANON_KEY;
const supabase = createClient(supabaseUrl, supabaseKey);

function flattenNodes(nodes) {
	/*
    "schema": {
        "heTitle": "תפארת שלמה",
        "enTitle": "Tiferet Shlomo",
        "key": "Tiferet Shlomo",
        "nodes": [
            {
                "heTitle": "על התורה",
                "enTitle": "on Torah",
                "nodes": [
                    {
                        "heTitle": "בראשית",
                        "enTitle": "Bereshit"
                    },
                    {
			*/
	let flattened = [];
	for (let node of nodes) {
		flattened.push(node);
		if (node.nodes) {
			flattened = flattened.concat(flattenNodes(node.nodes));
		}
	}
	return flattened;
}

function findHebrewTags(data, tags) {
	// Flatten the nested structure
	const allNodes = flattenNodes(data.schema.nodes);

	// Search by enTitle and return the heTitle for an array of tags
	let hebrewTags = [];
	for (let tag of tags) {
		let hebrewTag = allNodes.find(node => node.enTitle === tag)?.heTitle;
		if (hebrewTag) hebrewTags.push(hebrewTag);
	}
	return hebrewTags;
}
			

async function importTiferesShlomo() {
	var allToInsert = [];
  try {
    // Read the JSON file
    const data = JSON.parse(await fs.readFile('./Tiferet Shlomo - he - merged.json', 'utf8'));
    
    // Extract the text content
    const textContent = data.text;

	let count = 0;
    for (const [category, subcategories] of Object.entries(textContent)) {
      for (const [subcategory, texts] of Object.entries(subcategories)) {
        for (const [index, text] of texts.entries()) {
          var tags = [category, subcategory];

		  //search through the schema for the hebrew tag:
		  let hebrewTags = findHebrewTags(data,tags);
		  if(hebrewTags.length>0) tags.push(...hebrewTags);
  
		  //need to add another nesting level for pirkei avos!!! 
		  //Tiferet_Shlomo,_on_Festivals,_Pirkei_Avot.6.3

		  function createInsert(text, index, index2 = null) {
			const paragraphNumber = index2 !== null ? `${index + 1}.${index2 + 1}` : index + 1;
			const sefariaNameSuffix = index2 !== null ? `.${index2 + 1}` : '';

			return {
				source: 'Tiferet Shlomo',
				tags: tags,
				sefaria_name: `Tiferet_Shlomo,_${category},_${subcategory}.${index + 1}${sefariaNameSuffix}`.replaceAll(' ', '_'),
				paragraph: paragraphNumber,
				text: text,
			};
			}

		let inserts = Array.isArray(text)
		? text.map((paragraph, index2) => createInsert(paragraph, index, index2))
		: [createInsert(text, index)];


		  //console.log(inserts);
		  //count++;
		  //if(count>30) process.exit();

          allToInsert.push(...inserts);
        }
      }
    }

	// Insert into Supabase
	console.log('about to insert',allToInsert.length,'rows...')
	const { result, error } = await supabase
	.from('chassidus_texts')
	.insert(allToInsert);

  if (error) {
	return console.error('Error inserting row:', error);
  	} 

    console.log('Import completed successfully!');
  } catch (error) {
    console.error('Error during import:', error);
  }
}

importTiferesShlomo();

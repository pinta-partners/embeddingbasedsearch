import dotenv from '../dotenv.js';
import { OpenAI } from 'openai';
import pLimit from 'p-limit';
import pg from 'pg';

/*

Column	Type	Comment
id	uuid [uuid_generate_v4()]	
text	text	
embedding	vector(1536) NULL	
source	text	
tags	text[] NULL	
sefaria_name	text NULL	
paragraph	text NULL	
translation	text NULL	
translation_version	integer NULL	
created_at	timestamptz NULL [CURRENT_TIMESTAMP]	
updated_at	timestamptz NULL [CURRENT_TIMESTAMP]	
context	text NULL	
embedding_context	vector NULL	
summary	text NULL	
keywords	text[] NULL	



embedding_context_english	vector(3072) NULL	
embedding_context_english_hebrew	vector(3072) NULL	
embedding_english_hebrew	vector(3072) NULL	
embedding_hebrew_berel	vector(3072) NULL
*/

// Load environment variables
//dotenv.config({ path: '../.env', debug: true });

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

// OpenAI configuration
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Limit concurrent API calls
const limit = pLimit(150);

// Timeout for API calls (in milliseconds)
const API_TIMEOUT = 20000;

var i=0;

async function generateEmbeddings(translation, context, text) {
  try {
    const inputs = [
      `${context || ''}\n\n${translation}`.trim(),
      `${context || ''}\n\n${translation}\n\n${text}`.trim(),
      `${translation}\n\n${text}`.trim(),
    ];
	
	if (i%200==0) console.log(inputs);
	i++;

    const startTime = Date.now();
    const response = await Promise.race([
      openai.embeddings.create({
        model: "text-embedding-3-large",
        input: inputs,
      }),
      new Promise((_, reject) => 
        setTimeout(() => reject(new Error('OpenAI API timeout')), API_TIMEOUT)
      )
    ]);
    const endTime = Date.now();

    if((endTime - startTime) > 10000) console.log(`Embedding generation took ${endTime - startTime}ms for translation: "${translation.substring(0, 50)}..."`);

    return {
      embedding_context_english: response.data[0].embedding,
      embedding_context_english_hebrew: response.data[1].embedding,
      embedding_english_hebrew: response.data[2].embedding,
    };
  } catch (error) {
    console.error(`Error generating embeddings for translation: "${translation.substring(0, 50)}..."`, error);
    return null;
  }
}

async function updateEmbeddings(client, id, embeddings) {
  try {
    const startTime = Date.now();
    await client.query(
      `UPDATE chassidus_texts SET 
       embedding_context_english = $1::vector, 
       embedding_context_english_hebrew = $2::vector, 
       embedding_english_hebrew = $3::vector
       WHERE id = $4`,
      [
        JSON.stringify(embeddings.embedding_context_english),
        JSON.stringify(embeddings.embedding_context_english_hebrew),
        JSON.stringify(embeddings.embedding_english_hebrew),
        id
      ]
    );
    const endTime = Date.now();

    if((endTime - startTime) > 5000) console.log(`Embedding update took ${endTime - startTime}ms for id: ${id}`);
  } catch (error) {
    console.error(`Error updating embeddings for id: ${id}`, error);
    console.error('Error details:', error.message);
    if (error.detail) console.error('Error detail:', error.detail);
    if (error.hint) console.error('Error hint:', error.hint);
  }
}

async function processSentences() {
  let count = 0;
  let totalCount = 0;
  const batchSize = 500;

  while (true) {
    const client = await pool.connect();
    try {
      const startTime = Date.now();
      const result = await client.query(`
        SELECT id, translation, text, context
        FROM chassidus_texts
        WHERE embedding_context_english IS NULL 
        AND translation IS NOT NULL
        AND translation_version >= 5
        LIMIT $1
      `, [batchSize]);
      const sentences = result.rows;
      const endTime = Date.now();

      console.log(`Fetching sentences took ${endTime - startTime}ms`);

      if (sentences.length === 0) {
        console.log('No more sentences to process.');
        break;
      }

      console.log(`Processing ${sentences.length} sentences`);

      const promises = sentences.map(sentence => limit(async () => {
        const embeddings = await generateEmbeddings(sentence.translation, sentence.context, sentence.text);
        if (embeddings) {
          await updateEmbeddings(client, sentence.id, embeddings);
          count++;
          totalCount++;
          if (count % 20 === 0) {
            console.log(new Date().toISOString().split('T')[1] + `: Processed ${count} sentences in this batch, ${totalCount} total`);
            count = 0;
          }
        }
      }));

      await Promise.all(promises);
    } catch (error) {
      console.error('Error in processing batch:', error);
      // Wait for a short time before retrying
      await new Promise(resolve => setTimeout(resolve, 5000));
    } finally {
      client.release();
    }
  }

  console.log(`Finished processing ${totalCount} sentences.`);
}

processSentences().catch(console.error);

console.time('Execution time');
import fs from 'fs/promises';
import path from 'path';
import WordExtractor from 'word-extractor';

const SECTIONS = [
	{ parsha: 'Introduction', parsha_hebrew: 'הקדמה', position: 1 },
	{ parsha: 'Bereishis', parsha_hebrew: 'בראשית', position: 2 },
	{ parsha: 'Noach', parsha_hebrew: 'נח', position: 3 },
	{ parsha: 'Lech Lecha', parsha_hebrew: 'לך לך', position: 4 },
	{ parsha: 'Vayera', parsha_hebrew: 'וירא', position: 5 },
	{ parsha: 'Chayei Sarah', parsha_hebrew: 'חיי שרה', position: 6 },
	{ parsha: 'Toldos', parsha_hebrew: 'תולדות', position: 7 }
];
const volume = 'Volume 1';
const volume_hebrew = 'חלק ראשון';

const source = 'Divrei Yoel';
const source_hebrew = 'דברי יואל';

async function saveParshaSections(sections) {
  const outputDir = path.join(process.cwd(), 'divrei yoel');
  
  // Create output directory if it doesn't exist
  await fs.mkdir(outputDir, { recursive: true });

  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    const sectionInfo = SECTIONS[i];
    
    const filename = `Divrei Yoel ${volume}-${sectionInfo.position}-${sectionInfo.parsha}.txt`;
    const filepath = path.join(outputDir, filename);
    
    await fs.writeFile(filepath, section, 'utf8');
    console.log(`Saved ${filename}`);
  }
}

async function parseDocxFile(filePath) {
  try {
    // Read DOCX file
    const extractor = new WordExtractor();
    const buffer = await fs.readFile(filePath);
    const extracted = await extractor.extract(buffer);
    const content = extracted.getBody();
    
    // Split on #### to get major sections
    const sections = content.split(/####/).map(p => p.trim()).filter(p => p.length > 0);
    
	console.log(JSON.stringify(sections[1].slice(0,50000)));

    console.log('\nFound sections:', sections.length);
    sections.forEach((section, idx) => {
		console.log('\n' + '='.repeat(50));
		const MatchesTitle = section.startsWith(SECTIONS[idx].parsha_hebrew);
		console.log(`Section ${idx + 1}: ` + (MatchesTitle ? '✓':'x') + ' ' + SECTIONS[idx].parsha_hebrew);

		sections[idx] = sections[idx].replace(SECTIONS[idx].parsha_hebrew,'');//remove the parsha title from the first entry
	

	  console.log(SECTIONS[idx].parsha_hebrew,section.substring(0, 50)+'...')
      // Right-to-left mark and formatting for Hebrew
      //console.log('First Paragraph: \u200F' + paragraphs[0].substring(0, 150) + '...');
	  //console.log('Second paragraph: \u200F' + paragraphs[1].substring(0, 150) + '...');
    });

	

    // Process each section into paragraphs
    const structuredData = sections.map((section, index) => {
      // Split section into paragraphs
      const paragraphs = section.split(/\n\s*\n/).map(p => p.trim()).filter(p => p.length > 0);
      // Split into sub-paragraphs (split on double newlines)
      const subParagraphs = section
        .split(/\n+/)
        .map(sp => sp.trim())
        .filter(sp => sp.length > 0);

		

      return {
        paragraph_number: index + 1,
        full_text: section,
        character_length: section.length,
        sub_paragraphs: subParagraphs,
        sub_paragraph_count: subParagraphs.length
      };
    });

    return structuredData;
  } catch (error) {
    console.error('Error reading or parsing file:', error);
    throw error;
  }
}




async function main() {
  try {
    const filePath = path.join(process.cwd(), 'divrei yoel', 'divreiyoel1.docx');
    const parsedData = await parseDocxFile(filePath);
    // Extract just the full_text from each section
    const sectionTexts = parsedData.map(section => section.full_text);
    await saveParshaSections(sectionTexts);

    console.log('Processing complete!');
    console.timeEnd('Execution time');
    process.exit();
  } catch (error) {
    console.error('Error in main:', error);
  }
}

main().catch(console.error);

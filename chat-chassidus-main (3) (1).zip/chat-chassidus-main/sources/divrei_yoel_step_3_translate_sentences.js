import dotenv from '../dotenv.js';
import pg from 'pg';
import Anthropic from '@anthropic-ai/sdk';
import pLimit from 'p-limit';

// Token usage tracking
let totalInputTokens = 0;
let cacheCreationInputTokens = 0;
let cacheReadInputTokens = 0;
let totalOutputTokens = 0;

function calculateCost() {
  const inputCost = (totalInputTokens / 1e6) * 3;  // $3 per 1000 input tokens
  const outputCost = (totalOutputTokens / 1e6) * 15; // $15 per 1000 output tokens
  const cacheWriteCost = (cacheCreationInputTokens / 1e6) * 3.75; // $3.75 per 1000 tokens
  const cacheReadCost = (cacheReadInputTokens / 1e6) * 0.30; // $0.30 per 1000 tokens
  
  return {
    inputTokens: totalInputTokens,
    outputTokens: totalOutputTokens,
    cacheCreationInputTokens: cacheCreationInputTokens,
    cacheReadInputTokens: cacheReadInputTokens,
    inputCost: inputCost.toFixed(2),
    outputCost: outputCost.toFixed(2),
    cacheWriteCost: cacheWriteCost.toFixed(2),
    cacheReadCost: cacheReadCost.toFixed(2),
    totalCost: (inputCost + outputCost + cacheWriteCost + cacheReadCost).toFixed(2)
  };
}

function printStats() {
	const costs = calculateCost();
	console.log('\nUsage Statistics:');
	console.table([
	  {
		'Type': 'Input',
		'Cost': `$${costs.inputCost}`,
		'Tokens': costs.inputTokens.toLocaleString()
	  },
	  {
		'Type': 'Output',
		'Cost': `$${costs.outputCost}`,
		'Tokens': costs.outputTokens.toLocaleString()
	  },
	  {
		'Type': 'Cache Write',
		'Cost': `$${costs.cacheWriteCost}`,
		'Tokens': costs.cacheCreationInputTokens.toLocaleString()
	  },
	  {
		'Type': 'Cache Read',
		'Cost': `$${costs.cacheReadCost}`,
		'Tokens': costs.cacheReadInputTokens.toLocaleString()
	  },
	  {
		'Type': 'TOTAL',
		'Cost': `$${costs.totalCost}`,
		'Tokens': (costs.inputTokens + costs.outputTokens + costs.cacheCreationInputTokens + costs.cacheReadInputTokens).toLocaleString()
	  }
	]);
  }
  

// Shutdown handling
let forceExit = false;

// Handle interrupts
process.on('SIGINT', () => {
  if (forceExit) {
    console.log('Force exiting...');
    printStats();
    process.exit(1);
  } else {
    console.log('******Finishing current batch. Press Ctrl+C again to force exit.');
    forceExit = true;
  }
});

// PostgreSQL configuration
const pool = new pg.Pool({
  connectionString: process.env.POSTGRES,
});

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY
});

const prefill = `{"translation": "`;

const systemPrompt = `You are an expert translator of Jewish texts, particularly Chassidic works.
Your task is to translate Hebrew text into clear, accurate, modern English while preserving the original meaning and style.

Respond with valid JSON containing one key:
{"translation": "Your English translation, make sure to escape quoted text."}

If you cannot translate the text, respond with an error field explaining why.`;

//Please transliterate Hebrew names, rendering משה as Moshe and not Moses. -- probably better for embedding to let it use english names.

//only for full-paragraphs, not each sentence.
//- "summary": A 2-3 sentence summary of the key points
//- "keywords" (array): 5-10 key concepts discussed in the text.


function cleanJSON(jsonString) {
  return jsonString.replace(/,(\s*[}\]])/g, '$1');
}

const anthropic_headers= {
  //  'anthropic-beta': 'prompt-caching-2024-07-31'
  }
async function translateText(text,context) {
  var result_raw;
  try {
	let data = {
		model: process.env.ANTHROPIC_STRONG_MODEL || 'claude-3-5-sonnet-20241022',
		max_tokens: 5000,
		temperature: 0.2,
		system: [{
				type: 'text',
				text: systemPrompt// + `\n\n<context>${context}</context>`,
			//	"cache_control": {"type": "ephemeral"}
			}],
		messages: [
		  {
			role: "user",
			content: `Given the broader context, please translate just this section:
<source>${text}</source>`
		  },
		  {
			role: "assistant",
			content: prefill
		  }
		]
	  };
	//console.log(data);
    const message = await anthropic.messages.create(data, {headers: anthropic_headers});

    // Update token counts
    totalInputTokens += message.usage.input_tokens;
    totalOutputTokens += message.usage.output_tokens;
    
    // Track cache-related tokens if present
    if (message.usage.cache_creation_input_tokens) {
      cacheCreationInputTokens += message.usage.cache_creation_input_tokens;
    }
    if (message.usage.cache_read_input_tokens) {
      cacheReadInputTokens += message.usage.cache_read_input_tokens;
    }

	result_raw = prefill + message.content[0].text;
	//console.log('RESULT:', result_raw)

    // Complete and parse the JSON
    const result = JSON.parse(cleanJSON(result_raw));
    
	console.log(text);console.log(result.translation);console.log();

    // Validate the response format
    if (result.error) {
      throw new Error(result.error);
    }
    if (!result.translation ) { 
		console.log('RESULT:', result_raw)
      throw new Error('Invalid response format from Claude');
    }

    return result;
  } catch (error) {
	console.log('RAW RESULT: ',result_raw);
    console.error('Error in translation:', error);
    throw new Error('Error in translation: ' + error.message);

  }
}

async function processSingleSentence(limit, client, row) {
  return limit(async () => {
    try {
      console.log(`Translating sentence ID: ${row.id}`);
      const translation = await translateText(row.sentence, row.context);
      
      if (translation) {
        await client.query(
          `UPDATE chassidus_sentences 
           SET translation = $1,
               translation_version = 1
           WHERE id = $2`,
          [translation.translation, row.id]
		  //summary = $3, keywords = $4, //translation.summary, translation.keywords

        );
        console.log(`Updated translation for ID ${row.id}`);
      } else {
        throw new Error('Translation returned null');
      }
    } catch (error) {
      console.error(`Error processing sentence ${row.id}:`, error.message);
      
      // Store error message in translation field
      await client.query(
        `UPDATE chassidus_sentences 
         SET translation = $1,
             translation_version = 1
         WHERE id = $2`,
        [`ERROR: ${error.message}`, row.id]
      );
    }
  });
}

async function processSentences() {
  const client = await pool.connect();
  const limit = pLimit(20); // Limit to 10 concurrent operations
  let batch = 0;
  try {
    while (!forceExit) {
      batch++;
      if(batch>2) printStats();
      /*const result = await client.query(
        `SELECT cs.id, cs.sentence, ct.text as context
         FROM chassidus_sentences cs
         LEFT JOIN chassidus_texts ct ON cs.chassidus_text_id = ct.id
         WHERE cs.translation IS NULL 
         AND cs.source = 'Divrei Yoel'
         LIMIT 50`  // Fetch more rows but process with concurrency limit
      );
	  */
	  const result = await client.query(
        `SELECT cs.id, cs.sentence
         FROM chassidus_sentences cs
         WHERE cs.translation IS NULL 
         AND cs.source = 'Divrei Yoel'
         LIMIT 100`  // Fetch more rows but process with concurrency limit
      );

      if (result.rows.length === 0) {
        console.log('No more sentences to translate');
        break;
      }

      if (!forceExit) {
        // Process rows with concurrency limit
        await Promise.all(
          result.rows.map(row => processSingleSentence(limit, client, row))
        );
      } else {
        console.log('Graceful shutdown initiated - skipping remaining batches');
        break;
      }
    }
  } catch (error) {
    console.error('Error in main process:', error);
  } finally {
    printStats();
    client.release();
  }
}

processSentences().catch(error => {
  console.error(error);
  printStats();
});

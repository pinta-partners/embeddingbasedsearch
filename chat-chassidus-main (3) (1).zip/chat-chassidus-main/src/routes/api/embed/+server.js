import { json } from '@sveltejs/kit';
import OpenAI from 'openai';
import { supabase } from '$lib/supabase';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST({ request }) {
  const { text } = await request.json();

  try {
    const response = await openai.embeddings.create({
      model: 'text-embedding-3-large',
      input: text,
    });

    const [{ embedding }] = response.data;

    // Store the embedding in Supabase
    const { data, error } = await supabase
      .from('chassidus_texts')
      .insert({ text, embedding })
      .select();

    if (error) throw error;

    return json({ success: true, data });
  } catch (error) {
    console.error('Error:', error);
    return json({ error: 'An error occurred while processing your request.' }, { status: 500 });
  }
}

import { json } from '@sveltejs/kit';
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function POST({ request }) {
  const { message } = await request.json();

  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: `Write a concise title for this conversation in the given language.
Title in 5 Words or Less. No Punctuation or Quotation.
Must be in Title Case, written in the given Language.
Find an appropriate emoji to start the title.

Examples:
✡️ Parshas HaShevuah Insights
🕯️ Chassidic Teachings On Prayer
📜 Gemara Debate Key Concepts
🍎 Rosh Hashanah Customs Explained
👑 Jewish Perspectives on Moshiach` },
        { role: 'user', content: `Generate a title with an emoji for this chat message: "${message}"` }
      ],
      max_tokens: 60,
    });

    if (!response.choices || response.choices.length === 0) {
      throw new Error('No title generated');
    }

    const title = response.choices[0].message.content.trim();
    if (!title) {
      throw new Error('Empty title generated');
    }

    return json({ title });
  } catch (error) {
    console.error('Error generating title:', error);
    return json({ error: `Failed to generate title: ${error.message}` }, { status: 500 });
  }
}

import { json } from '@sveltejs/kit';
import { findSimilarDocuments } from '$lib/embeddingUtils.js';
import { getSourceAnalysis } from '$lib/claudeUtils.js';
import Anthropic from '@anthropic-ai/sdk';

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});
function joinSentences(sentences) {
	//given a list of objects, convert it into plain text separated by new lines.
	//when `sentence_number` is more than 1 past the previous, add a line of ...

	return sentences.reduce((accumulator, current, index) => {
		let text = current.text.trim();
		if(text=='' || text == '\n') return accumulator;

		if (index > 0 && current.sentence_number > sentences[index - 1].sentence_number + 1) {
			accumulator += '\n...\n';
		}
		return accumulator + text + '.\n';
	}, '');

	}
async function processBatch(docs, userMessage, startIndex) {
  return Promise.all(
    docs.map(async (doc, index) => {
      if (!doc || typeof doc !== 'object') return null;
      
      try {
        const analysis = await getSourceAnalysis(
          doc.text,
          doc.matching_sentences?.map(s => s.text) || [],
          userMessage
        );
        
        return {
          ...doc,
          analysis,
          originalIndex: startIndex + index
        };
      } catch (error) {
        console.error(`Error analyzing document ${startIndex + index}:`, error);
        // Try once more on failure
        try {
          const analysis = await getSourceAnalysis(
            doc.text,
            doc.matching_sentences?.map(s => s.text) || [],
            userMessage
          );
          return {
            ...doc,
            analysis,
            originalIndex: startIndex + index
          };
        } catch (retryError) {
          console.error(`Retry failed for document ${startIndex + index}:`, retryError);
          return null;
        }
      }
    })
  );
}

async function enrichDocumentsWithAnalysis({documents, userMessage, desiredResults=10}) {
  if (!documents || !Array.isArray(documents)) {
    return [];
  }

  const batchSize = 10;
  const enrichedDocs = [];
  let failureCount = 0;
  const MAX_FAILURES = 3; // Stop after 3 fails
  
  // Process documents in batches
  for (let startIdx = 0; startIdx < documents.length; startIdx += batchSize) {
    // If we already have 10 relevant docs or too many failures, stop processing
    if (enrichedDocs.length >= desiredResults || failureCount >= MAX_FAILURES) break;

    const batch = documents.slice(startIdx, startIdx + batchSize);
    const batchResults = await processBatch(batch, userMessage, startIdx);
    
    // Count failures in this batch
    const batchFailures = batchResults.filter(doc => !doc?.analysis?.relevance?.relevance_score).length;
    if (batchFailures) { // If more than half the batch failed
      failureCount+=batchFailures;
      console.error(`Batch ${Math.floor(startIdx/batchSize)} had ${batchFailures} failures. Total failure count: ${failureCount}`);
      if (failureCount >= MAX_FAILURES) {
        console.error('Too many failures, stopping document processing');
        break;
      }
    }
    
    // Filter valid results with relevance score > 5
    const validBatchResults = batchResults
      .filter(doc => doc !== null && doc.analysis?.relevance?.relevance_score > 5)
      .sort((a, b) => 
        (b.analysis?.relevance?.relevance_score || 0) - 
        (a.analysis?.relevance?.relevance_score || 0)
      );

    enrichedDocs.push(...validBatchResults);
  }

  // Sort all results by relevance score
  const sortedEnrichedDocs = enrichedDocs.sort((a, b) => 
    (b.analysis?.relevance?.relevance_score || 0) - 
    (a.analysis?.relevance?.relevance_score || 0)
  );

  // If we have fewer enriched docs than desired, supplement with original documents
  if (sortedEnrichedDocs.length < desiredResults) {
    const enrichedIds = new Set(sortedEnrichedDocs.map(doc => doc.id));
    const remainingDocs = documents
      .filter(doc => !enrichedIds.has(doc.id))
      //.sort((a, b) => (b.similarity || 0) - (a.similarity || 0))
      .slice(0, desiredResults - sortedEnrichedDocs.length);
    
    return [...sortedEnrichedDocs, ...remainingDocs];
  }

  return sortedEnrichedDocs;
}

async function formatDocuments(documents) {
  if (!documents || !Array.isArray(documents)) {
    return '';
  }

  const formattedDocs = documents.map((doc, index) => {
    const {
      source = '',
      sefaria_name = '',
      name_pretty = '',
      name_pretty_hebrew = '',
      similarity = 0,
      summary = '',
      text = '',
      context = '',
      matching_sentences = [],
      tags = [],
      analysis = {}
    } = doc;
    
    return `<source-${index + 1}>
<sefer>${source || sefaria_name}</sefer>
<name_pretty>${name_pretty||source}</name_pretty>
<name_pretty_hebrew>${name_pretty_hebrew||source}</name_pretty_hebrew>
<similarity>${similarity.toFixed(4)}</similarity>
<tags>${tags.join(', ')}</tags>
<summary>${summary}</summary>
<context>${context}</context>
<sefaria_link>${sefaria_name ? `https://www.sefaria.org/${encodeURIComponent(sefaria_name)}` : ''}</sefaria_link>
<relevance_score>${analysis.relevance?.relevance_score}</relevance_score>
<matching_sentences>${joinSentences(matching_sentences)}</matching_sentences>
<text>${text.replaceAll('<br>', '<br />')}</text>
<headline_hebrew>${analysis.headline?.hebrew}</headline_hebrew>
<headline_english>${analysis.headline?.english}</headline_english>
<conclusion_hebrew>${analysis.conclusion?.hebrew}</conclusion_hebrew>
<conclusion_english>${analysis.conclusion?.english}</conclusion_english>
</source-${index + 1}>`;
  });

  return formattedDocs.join('\n\n');
}

export async function POST({ request }) {
  const { messages, preferredLanguage, selectedSource } = await request.json();
  
  console.log('ORIGINAL DATA')
  console.log(messages);

  const userMessage = messages.find(m => m.role === "user")?.content || messages.find(m => m.role === "user")?.text;
  if (!userMessage) {
    console.error('No user message found in:', messages);
    return json({ error: 'No user message found in conversation' }, { status: 400 });
  }

  try {
    let finalMessages = [...messages];
    const needsContext = !messages.some(m => 
      (m.role === "system" || m.role=='assistant' || m.sender === "ai") && 
      (m.content?.startsWith("Context:") || m.context)
    );
    let context = '';

    // Get context if needed
    if (needsContext) {
      console.log('performing RAG lookup...');
      const documents = await findSimilarDocuments({
        embeddingColumn: 'embedding_large_english_hebrew',
        searchOrEmbedding: userMessage,
        limit: 50,
        sourceFilter: selectedSource !== 'all' ? selectedSource : null
      });
      const enrichedDocs = await enrichDocumentsWithAnalysis({documents, userMessage, desiredResults: 7});
      context = await formatDocuments(enrichedDocs);
      
      finalMessages.unshift({
        role: "user",
        content: `Context:\n${context}`
      });
    }

// Prepare system message
const systemMessage = `<instructions>Your job is to analyze and answer questions through the lens of Chassidic thought (specifically excluding Chabad teachings).
		
I will provide you with:

- A question someone has asked
- Multiple paragraphs of texts

Your task is to:
a) Using ONLY the relevant paragraphs (using the "relevance_score" out of 10), formulate a response in the style of Rav Moshe Feinstein's responsa
b) Never include any information that isn't in the provided paragraphs, even if you know it to be true

The response should be written in high-level language in ${preferredLanguage === 'hebrew' ? 'Hebrew' : 'English'}, following the formal style of Rav Moshe Feinstein's responsa.
</instructions>
<example response english>
Regarding the Explanation of Taamei HaMitzvos and Their Reward

I have come to explain and teach regarding the elevated matter of the reasons for mitzvos and their reward, which many great scholars have discussed. Although our understanding is limited in grasping the deep intentions of the Creator, blessed be His name, we will attempt with Hashem's help to shed some light on this topic.

First, let us begin with the words of the holy Torah in Sefer Devarim (7:12): "And it shall come to pass, because you hearken to these judgments, and keep, and do them, that Hashem your G-d shall keep unto you the covenant and the kindness which He swore unto your forefathers." From this posuk, we learn that there is reward for mitzvos, but we must understand the depth of these matters.

The Gemara in Sanhedrin (21b) states: "Rav Yitzchak said: Why were the reasons for the Torah's commandments not revealed? Because in two instances where reasons were revealed, a great person stumbled because of them." From this, we learn there are limits to our investigation of taamei hamitzvos, and we must be careful not to stumble due to our limited understanding.

In Medrash Rabbah (Bereishis Parsha 44:1), Chazal expounded on the purpose of mitzvos, stating: "What difference does it make to HaKadosh Boruch Hu whether one slaughters from the front of the neck or the back? Rather, the mitzvos were given to refine people." Thus, the main purpose of mitzvos is to purify a person and correct their midos, not merely the technical details of the actions.

The Rambam elaborated on this in Hilchos Teshuva (10:1), writing: "A person should not say 'I will perform the Torah's mitzvos and study its wisdom to receive all the blessings written in it or to merit Olam Haba.'" His words clarify that one who serves out of fear of punishment or hope for reward is considered among those of limited understanding, and this is not the way of chachomim and tzaddikim.

The Ramchal in his clear work "Mesillas Yesharim" illuminated our understanding of creation's purpose and avodas Hashem. He explained that a person's main purpose is to delight in Hashem and enjoy the radiance of the Shechinah, and this is the true reward. According to this, mitzvos are tools for achieving this lofty goal, not an end in themselves.

On this matter, the holy meforshim, including the Sforno, Kli Yakar, Ohr HaChaim, and Malbim, wrote on the posuk in Devarim (7:12) that the concept of reward is complex and deep. Some mitzvos naturally lead to positive results in this world, while others primarily affect our spiritual state. They further explained that the simcha and spiritual elevation experienced while performing mitzvos are themselves a form of reward.

From all this, we find that the system of reward and punishment should not be viewed as a physical transaction, but rather as a spiritual framework enabling a person to elevate themselves and draw closer to their Creator. As we learned in Pirkei Avos (1:3): "Do not be like servants who serve their master for the sake of receiving a reward, rather be like servants who serve their master not for the sake of receiving a reward."

In practice, it appears that it is permitted and even proper to explain and teach about taamei hamitzvos and their reward, but this must be done with wisdom and caution. We must emphasize that the ultimate purpose is avodas Hashem from love, and that the system of mitzvos and reward is designed to assist in our spiritual development and drawing closer to Hashem Yisborach.

May it be His will that we merit to fulfill Hashem's mitzvos out of pure love and yirah, and may we merit to delight in Hashem and enjoy the radiance of His Shechinah, Amein.

Writing and signing for the honor of Torah and its learners,
Rav Binah Melachutis Dictos
</example response english>
<example response hebrew>
בעניין ביאור טעמי המצוות ושכרן

הנה באתי לבאר ולהורות בעניין הנשגב של טעמי המצוות ושכרן, אשר רבים וגדולים דשו בו. ואף שקצרה דעתנו מלהשיג עומק כוונת הבורא יתברך שמו, ננסה בעזרת השם להאיר מעט מזעיר בסוגיא זו.

ראשית, נפתח בדברי התורה הקדושה בספר דברים (ז:יב): "והיה עקב תשמעון את המשפטים האלה ושמרתם ועשיתם אֹתם ושמר ה' אלהיך לך את הברית ואת החסד אשר נשבע לאבֹתיך". והנה, מפסוק זה למדנו שיש שכר למצוות, אך עלינו להבין עומק הדברים.

ובגמרא סנהדרין (כא ע"ב) איתא: "אמר רבי יצחק: מפני מה לא נתגלו טעמי תורה? שהרי שתי מקראות נתגלו טעמן נכשל בהן גדול העולם". ומזה נלמד שיש גבול לחקירתנו בטעמי המצוות, ועלינו להיזהר שלא להיכשל בהבנתנו המוגבלת.

והנה במדרש רבה (בראשית פרשה מד סימן א) הפליגו חז"ל בביאור תכלית המצוות, וזה לשונם: "וכי מה איכפת ליה להקב"ה למי ששוחט מן הצואר או מי ששוחט מן העורף, הוי לא נתנו המצות אלא לצרף בהן את הבריות". הרי שעיקר מטרת המצוות היא זיכוך האדם ותיקון מידותיו, ולא פרטי המעשים גרידא.

ובאמת, כבר האריך בזה הרמב"ם בהלכות תשובה (פ"י ה"א), וזה לשונו: "אל יאמר אדם הריני עושה מצוות התורה ועוסק בחכמתה כדי שאקבל כל הברכות הכתובות בה או כדי שאזכה לחיי העולם הבא". ומבואר בדבריו כי העובד מיראת העונש או מתוך תקווה לשכר, הרי זה בבחינת קטני הדעת, ואין זו דרכם של חכמים וצדיקים.

והנה, הרמח"ל זצ"ל בספרו הבהיר 'מסילת ישרים', האיר עינינו בהבנת תכלית הבריאה ועבודת ה'. וביאר שם כי עיקר מטרת האדם היא להתענג על ה' וליהנות מזיו שכינתו, וזהו השכר האמיתי. ולפי זה, המצוות הן כלי להשגת מטרה נשגבה זו, ולא תכלית לעצמן.

ובעניין זה כתבו המפרשים הקדושים, ובהם הספורנו, הכלי יקר, האור החיים והמלבי"ם על הפסוק בדברים (ז:יב), כי מושג השכר הוא מורכב ועמוק. יש מצוות שמובילות באופן טבעי לתוצאות חיוביות בעולם הזה, ויש שמשפיעות בעיקר על מצבנו הרוחני. ועוד ביארו כי השמחה וההתעלות הרוחנית שחווים בקיום המצוות הן בעצמן צורה של שכר.

ונמצא לפי כל זה, כי אין לראות את מערכת השכר והעונש כעסקה גשמית, אלא כמסגרת רוחנית המאפשרת לאדם להתעלות ולהתקרב לבוראו. וכבר שנינו באבות (פרק א משנה ג): "אל תהיו כעבדים המשמשים את הרב על מנת לקבל פרס, אלא הוו כעבדים המשמשים את הרב שלא על מנת לקבל פרס".

ולמעשה, נראה שמותר ואף ראוי לבאר ולהורות בעניין טעמי המצוות ושכרן, אך יש לעשות זאת בחכמה ובזהירות. יש להדגיש כי התכלית העליונה היא עבודת ה' מאהבה, וכי מערכת המצוות והשכר נועדה לסייע בהתפתחותנו הרוחנית ובהתקרבותנו לבורא יתברך.

ויהי רצון שנזכה לקיים מצוות ה' מתוך אהבה ויראה טהורה, ונזכה להתענג על ה' וליהנות מזיו שכינתו, אמן.

הכותב וחותם לכבוד התורה ולומדיה,
הרב בינה מלאכותית דיקטוש
</example response hebrew>
`


    //console.log('FINAL MESSAGES:');
    //console.log(finalMessages);

    // Stream the response
    return new Response(
      new ReadableStream({
        async start(controller) {
          const encoder = new TextEncoder();

          // If we have new context, send it first
          if (needsContext && context) {
            controller.enqueue(encoder.encode(context + '\n===CONTEXT===\n'));
          }

          // Then stream the chat completion
          try {
            // Prepare messages by moving context into content
            const processedMessages = finalMessages
              .filter(m => m.role !== 'system')
              .map(m => ({
                role: m.role,
                content: m.context ? `Context:\n${m.context}\n\n${m.content}` : m.content
              }));

            const stream = await anthropic.messages.stream({
              model: process.env.ANTHROPIC_STRONG_MODEL || 'claude-3-5-sonnet-20241022',
              system: systemMessage,
              messages: processedMessages,
              max_tokens: 4096,
            });

            for await (const chunk of stream) {
              if (chunk.type === 'content_block_delta' && chunk.delta?.text) {
                controller.enqueue(encoder.encode(chunk.delta.text));
              }
            }
            controller.close();
          } catch (error) {
            console.error('Stream error:', error);
            controller.error(error);
          }
        },
      }),
      {
        headers: {
          'Content-Type': 'text/event-stream',
          'Cache-Control': 'no-cache',
          'Connection': 'keep-alive'
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    if (error.status === 429) {
      return json({ error: 'Rate limit exceeded. Please try again later.' }, { status: 429 });
    }
    return json({ error: 'An error occurred while processing your request.' }, { status: 500 });
  }
}

import { json } from '@sveltejs/kit';
import pg from 'pg';

const pool = new pg.Pool({
  connectionString: process.env.POSTGRES
});

export async function GET({ url }) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      `SELECT id, title, visible, updated_at 
       FROM chats 
       WHERE visible = true 
       ORDER BY updated_at DESC`
    );
    return json(result.rows);
  } catch (error) {
    console.error('Error loading chats:', error);
    return json({ error: error.message }, { status: 500 });
  } finally {
    client.release();
  }
}

export async function POST({ request }) {
  const client = await pool.connect();
  try {
    const { title, messages, visible = true } = await request.json();
    const result = await client.query(
      `INSERT INTO chats (title, messages, visible) 
       VALUES ($1, $2::jsonb, $3) 
       RETURNING *`,
      [title, JSON.stringify(messages), visible]
    );
    return json(result.rows[0]);
  } catch (error) {
    console.error('Error creating chat:', error);
    return json({ error: error.message }, { status: 500 });
  } finally {
    client.release();
  }
}

export async function PATCH({ request }) {
  const client = await pool.connect();
  try {
    const { id, title, visible, messages } = await request.json();
    if (!id || id === 'new') {
      return json({ error: 'Invalid chat ID' }, { status: 400 });
    }
    const updates = [];
    const values = [id];
    let paramCount = 1;

    if (title !== undefined) {
      updates.push(`title = $${++paramCount}`);
      values.push(title);
    }
    if (visible !== undefined) {
      updates.push(`visible = $${++paramCount}`);
      values.push(visible);
    }
    if (messages !== undefined) {
      updates.push(`messages = $${++paramCount}::jsonb`);
      values.push(JSON.stringify(messages));
    }
    updates.push(`updated_at = NOW()`);

    const result = await client.query(
      `UPDATE chats 
       SET ${updates.join(', ')} 
       WHERE id = $1 
       RETURNING *`,
      values
    );
    return json(result.rows[0]);
  } catch (error) {
    console.error('Error updating chat:', error);
    return json({ error: error.message }, { status: 500 });
  } finally {
    client.release();
  }
}

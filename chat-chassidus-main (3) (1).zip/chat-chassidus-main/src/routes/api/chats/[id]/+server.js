import { json } from '@sveltejs/kit';
import pg from 'pg';

const pool = new pg.Pool({
  connectionString: process.env.POSTGRES
});

export async function GET({ params }) {
  const client = await pool.connect();
  try {
    const result = await client.query(
      'SELECT * FROM chats WHERE id = $1',
      [params.id]
    );
    
    if (result.rows.length === 0) {
      return json({ error: 'Chat not found' }, { status: 404 });
    }
    
    return json(result.rows[0]);
  } catch (error) {
    console.error('Error loading chat:', error);
    return json({ error: error.message }, { status: 500 });
  } finally {
    client.release();
  }
}

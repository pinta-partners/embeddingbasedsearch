<script>
  import { page } from '$app/stores';
  import ChatInterface from '$lib/components/ChatInterface.svelte';

  const chatId = $page.params.slug;
</script>

<ChatInterface {chatId} />

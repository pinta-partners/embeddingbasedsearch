<script>
  import { page } from '$app/stores';
  import { goto } from '$app/navigation';
  import ChatList from '$lib/components/ChatList.svelte';
  import ChatInterface from '$lib/components/ChatInterface.svelte';
  import { updateChatTitle } from '$lib/stores/chatStore';  // Add this import

  export let data;
  $: ({ chat } = data);

  $: selectedChatId = $page.params.id;

  function handleChatSelect(event) {
    const { id } = event.detail;
    if (id) {
      goto(`/chat/${id}`);
    } else {
      goto('/');
    }
  }

  function handleTitleChange(event) {
    const { chatId, title } = event.detail;
    updateChatTitle(chatId, title);
  }
</script>

<div class="chat-container">
  <ChatList on:chatSelect={handleChatSelect} {selectedChatId} />
  <div class="chat-interface">
    {#if selectedChatId}
      <ChatInterface 
        chatId={selectedChatId} 
        {chat} 
        on:titleChange={handleTitleChange}
      />
    {:else}
      <div class="no-chat-selected">
        <p>Select a chat from the list or start a new one.</p>
      </div>
    {/if}
  </div>
</div>

<style>
  .chat-container {
    display: flex;
    height: calc(100vh - 100px);
  }
  .chat-interface {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    padding: 20px;
  }
  .no-chat-selected {
    flex-grow: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 1.2em;
    color: #666;
  }
</style>

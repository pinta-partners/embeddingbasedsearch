import { error } from '@sveltejs/kit';
import { getChatById } from '$lib/stores/chatStore';
import getJewishInfo from '$lib/jewish-info';

export async function load({ params, fetch }) {
  if (params.id === 'new') {
    const jewishInfo = getJewishInfo();
    return {
      chat: {
        id: 'new',
        title: 'New Chat',
        messages: [{ text: `Welcome to Chassidus Chat! How can I assist you today?\n\nHere's some relevant Jewish information:\n\n${jewishInfo}`, sender: 'ai' }],
        visible: true
      }
    };
  }

  const chat = await getChatById(params.id, fetch);
  
  if (chat) {
    return { chat };
  }
  
  throw error(404, 'Chat not found');
}

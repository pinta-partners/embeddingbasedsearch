<script>
  import { onMount } from 'svelte';
  import { page } from '$app/stores';
  import { goto } from '$app/navigation';
  import ChatList from '$lib/components/ChatList.svelte';
  import ChatInterface from '$lib/components/ChatInterface.svelte';

  let selectedChatId;
  let chatListComponent;
  let isNewChat = false;
  let initialTitle = '';

  $: selectedChatId = $page.params.slug;

  function handleChatSelect(event) {
	//console.log(event)
    const { id, title, isNew } = event.detail;
    isNewChat = isNew;
    initialTitle = title;
    selectedChatId = id;
    if (id) {
      goto(`/chat/${id}`);
    } else {
      goto('/');
    }
  }

  async function handleVisibilityChange(event) {
    const { chatId, isVisible } = event.detail;
    if (chatListComponent) {
      await chatListComponent.handleVisibilityChange(chatId, isVisible);
     /* if (!isVisible && selectedChatId === chatId) {
        selectedChatId = null;
        history.pushState(null, '', '/');
      }*/
    }
  }

  async function handleTitleChange(event) {
    const { chatId, title } = event.detail;
    if (chatListComponent) {
      await chatListComponent.handleTitleChange(chatId, title);
    }
  }
</script>

<svelte:head>
  <title>Chat-Tiferes-Shlomo</title>
</svelte:head>

<main>
  <h1>Chassidus: Tiferes Shlomo</h1>
  <div class="chat-container">
    <ChatList bind:this={chatListComponent} on:chatSelect={handleChatSelect} {selectedChatId} />
    {#if selectedChatId}
      <ChatInterface 
        chatId={selectedChatId} 
        isNewChat={isNewChat} 
        initialTitle={initialTitle}
        on:visibilityChange={handleVisibilityChange} 
        on:titleChange={handleTitleChange} 
      />
    {:else}
      <div class="no-chat-selected">
        <p>Select a topic from the list or start a new one.</p>
      </div>
    {/if}
  </div>
</main>

<style>
  main {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
  }
  h1 {
    text-align: center;
    color: #333;
    margin-bottom: 20px;
  }
  .chat-container {
    display: flex;
    height: calc(100vh - 100px);
    overflow: hidden;
  }
  .no-chat-selected {
    flex-grow: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    font-size: 1.2em;
    color: #666;
  }
</style>

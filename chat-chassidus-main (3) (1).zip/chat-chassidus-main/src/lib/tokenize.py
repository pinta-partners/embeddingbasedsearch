# Load model directly
from transformers import AutoTokenizer, AutoModelForMaskedLM

tokenizer = AutoTokenizer.from_pretrained("dicta-il/BEREL_2.0")
model = AutoModelForMaskedLM.from_pretrained("dicta-il/BEREL_2.0")
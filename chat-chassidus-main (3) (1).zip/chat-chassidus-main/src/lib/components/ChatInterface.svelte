<script>
  import { tick, onMount } from 'svelte';
  import { goto } from '$app/navigation';
  import MarkdownIt from 'markdown-it';
  import { writable } from 'svelte/store';
  const expandedSources = writable(new Set());
  const expandedFullText = writable(new Set());
  import getJewishInfo from '$lib/jewish-info';
  import { browser } from '$app/environment';

  export let chatId = null;
  export let isNewChat = false;
  export let initialTitle = '';

  let messages = [];
  const md = new MarkdownIt();
  let userInput = '';
  let isLoading = false;
  let inputElement;
  let isVisible = true;
  let chatTitle = '';
  let sources = [];
  let selectedSource = 'all'; // default to 'all', will be overridden by cookie
  let preferredLanguage = 'english';

  onMount(() => {
    if (browser) {
      const cookies = document.cookie.split(';').map(c => c.trim());
      
      // Get saved language preference
      const savedLanguage = cookies.find(c => c.startsWith('preferredLanguage='));
      if (savedLanguage) {
        const value = savedLanguage.split('=')[1];
        console.log('Found saved language:', value);
        preferredLanguage = value;
      } else {
        console.log('No saved language preference found');
      }

      // Get saved source filter preference
      const savedSourceFilter = cookies.find(c => c.startsWith('selectedSource='));
      if (savedSourceFilter) {
        const value = savedSourceFilter.split('=')[1];
        console.log('Found saved source filter:', value);
        selectedSource = value;
      } else {
        console.log('No saved source filter found');
      }
    }
  });

  function setCookie(name, value) {
    if (browser) {
      const isLocalhost = window.location.hostname === 'localhost';
      const cookieOptions = [
        `${name}=${value}`,
        'path=/',
        'max-age=31536000',
        'SameSite=Lax'
      ];

      // Add Domain for localhost, add Secure for production
      if (isLocalhost) {
        cookieOptions.push('Domain=localhost');
      } else {
        cookieOptions.push('Secure');
      }

      document.cookie = cookieOptions.join('; ');
      console.log('Setting cookie:', name, '=', value, 'on', window.location.hostname);
    }
  }

  function setLanguageCookie(lang) {
    setCookie('preferredLanguage', lang);
  }

  function setSourceFilterCookie(source) {
    setCookie('selectedSource', source);
  }

  /*$: if (preferredLanguage) {
    setLanguageCookie(preferredLanguage);
  }*/ //this was resetting it onload somehow to the default of english

function onlyHebrew(str) {
  if (typeof str !== 'string') return '';
  
  // Regular expression to match Hebrew characters
  const hebrewRegex = /[\u0590-\u05FF\uFB1D-\uFB4F\u0591-\u05C7]/g;
  
  // Function to calculate the percentage of Hebrew characters in a string
  const hebrewPercentage = (s) => {
    const hebrewChars = (s.match(hebrewRegex) || []).length;
    return hebrewChars / s.length;
  };
  const percentage = hebrewPercentage(str);

  // Return the string if it's at least 50% Hebrew, otherwise return an empty string
  return percentage >= 0.5 ? str : '';
}

function checkLanguage(messageContent){
		const hebrewRegex = /[\u0590-\u05FF\uFB1D-\uFB4F\u0591-\u05C7]/g;
		const hebrewChars = (messageContent.match(hebrewRegex) || []).length;
		const totalChars = messageContent.length;
		
		if (hebrewChars && (hebrewChars / totalChars > 0.5)) return 'rtl';
		return 'ltr';
	}



  function processCitations(text) {
    if (!text) return '';
    const regex = /<source-(\d+)>([\s\S]*?)<\/source-\1>/g;
    let lastIndex = 0;
    let result = '';
    let citationCount = 1;
    sources = [];

    for (const match of text.matchAll(regex)) {
      const [fullMatch, index, sourceContent] = match;
      const sourceData = parseSource(sourceContent);
      sources.push(sourceData);
    
      const citation = `[${citationCount}]`;
      result += text.slice(lastIndex, match.index);
      result += `${sourceData.text} ${citation}`;
      lastIndex = match.index + fullMatch.length;
      citationCount++;
    }

    result += text.slice(lastIndex);

    // Add footnotes
    if (sources.length > 0) {
      result += '\n\nSources:\n';
      sources.forEach((source, index) => {
        result += `[${index + 1}] ${source.sefer}\n`;
      });
    }

    return result;
  }

  function parseSource(content, isMultiple = false) {
    try {
      if (isMultiple) {
        const sources = content.split('<source-');
        return sources.slice(1).map(source => parseSourceContent(`<source-${source}`));
      }
      return parseSourceContent(content);
    } catch (error) {
      console.error('Error parsing source:', error);
      return isMultiple ? [] : null;
    }
  }

function parseSourceContent(content) {
	const parser = new DOMParser();
	const doc = parser.parseFromString(content, 'text/xml');
  
	// Grab all nodes
	const result = {};
	const nodes = doc.documentElement.childNodes;
  
	for (let node of nodes) {
		if (node.nodeType === Node.ELEMENT_NODE) {
			const tagName = node.tagName.toLowerCase();
			result[tagName] = node.textContent || '';
		}
	}

  // Handle special cases
  if (result.tags) result.tags = result.tags.split(', ');
  if (result.matching_sentences) result.matching_sentences = parseMatchingSentences(result.matching_sentences);

  // Set default values for all fields
  result.tags = result.tags || [];
  var defaultToBlank=['context','summary','sefaria_link','text','headline_hebrew','headline_english','conclusion_hebrew','conclusion_english','sefer','similarity', 'relevance_score' ]
  defaultToBlank.forEach(function(title){
	if(!result[title]) result[title]='';
  	})
  

  // Use specific tags for names
  result.name_pretty_hebrew = result.name_pretty_hebrew || result.sefer;
  result.name_pretty = result.name_pretty || result.sefer;

  return result;
}


  function parseMatchingSentences(text) {
    if (!text) return [];
    const sentences = text.split('\n').filter(s => s.trim());
    return sentences;
  }


  $: if (chatId === 'new') {
    initializeNewChat();
  } else if (chatId) {
    loadChat(chatId);
  } else {
    // Reset the chat interface when no chat is selected
    resetChatInterface();
  }

  function initializeNewChat() {
    chatTitle = initialTitle || 'New Chat';
    const jewishInfo = getJewishInfo();
    messages = [{ role: 'assistant', content: `Welcome to Chassidus Chat! How can I assist you today?\n\nHere's some relevant Jewish information:\n\n${jewishInfo}` }];
    isVisible = true;
  }

  function resetChatInterface() {
    const jewishInfo = getJewishInfo();
    messages = [{ role: 'assistant', content: `Welcome to Chassidus Chat! How can I assist you today?\n\nHere's some relevant Jewish information:\n\n${jewishInfo}` }];
    chatTitle = '';
    isVisible = true;
    isNewChat = false;
  }

  import { invalidate } from '$app/navigation';

  // Helper function to get the appropriate fetch
  const getFetch = async () => {
    if (browser) {
      return window.fetch;
    }
    const { fetch } = await import('$app/navigation');
    return fetch;
  };

  async function loadChat(id) {
    if (!id || !browser) return;

    try {
      const fetch = window.fetch;
      const response = await fetch(`/api/chats/${id}`);
      if (!response.ok) throw new Error('Failed to load chat');
      
      const data = await response.json();
      messages = data.messages.map(msg => {
        // Handle both old and new message formats
        const role = msg.role || (msg.sender === 'user' ? 'user' : 'assistant');
        const content = msg.content || msg.text || '';
        const context = msg.context || null;
        return { role, content, context };
      });
      console.log('Loaded messages:', messages);
      isVisible = data.visible;
      chatTitle = data.title;
    } catch (error) {
      console.error('Error loading chat:', error);
      resetChatInterface();
      if (browser) {
        goto('/');
      }
    }
  }

  function handleKeydown(event) {
    if (event.key === 'Enter' && (event.ctrlKey || (!event.shiftKey && !event.ctrlKey))) {
      event.preventDefault();
      handleSubmit();
    }
  }

  function autoGrow(event) {
    event.target.style.height = 'auto';
    event.target.style.height = event.target.scrollHeight + 'px';
  }

  async function handleSubmit() {
    if (userInput.trim() && !isLoading) {
      const currentInput = userInput.trim();
      userInput = '';
      isLoading = true;
      
      // Create message objects but don't update state yet
      const userMessage = { role: 'user', content: currentInput };
      
      try {
        // Handle new chat creation first
        if (!chatId || chatId === 'new' || !chatTitle || chatTitle.trim() === '') {
          const { chatId: savedChatId, title: generatedTitle } = await saveNewChat(chatTitle, userMessage);
          if (savedChatId) {
            chatId = savedChatId;
            chatTitle = generatedTitle;
            goto(`/chat/${savedChatId}`, { replaceState: true });
            dispatch('titleChange', { chatId: savedChatId, title: generatedTitle });
          } else {
            throw new Error('Failed to save new chat');
          }
        }

        // Now update messages state once
        messages = [...messages, userMessage];

        // Send only the necessary messages to the API
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ 
            messages: messages.filter(m => m.content.trim() !== ''), // Filter out empty messages
            preferredLanguage,
            selectedSource
          }),
        });

        if (!response.ok) {
          throw new Error('API request failed');
        }

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let aiMessage = { role: 'assistant', content: '', context: null };
        messages = [...messages, aiMessage];

        let fullResponse = '';
        let saveCounter = 0;
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          const chunk = decoder.decode(value);
          fullResponse += chunk;
          
          // Check if the chunk contains the context delimiter
          const contextDelimiter = '===CONTEXT===';
          const contextIndex = fullResponse.indexOf(contextDelimiter);
          
          if (contextIndex !== -1) {
            // Extract context and update aiMessage
            aiMessage.context = fullResponse.slice(0, contextIndex).trim();
            fullResponse = fullResponse.slice(contextIndex + contextDelimiter.length);
          }
          
          aiMessage.content = processCitations(fullResponse.trim());
          messages = [...messages.slice(0, -1), aiMessage];
          
          // Save chat after context is received
          if (contextIndex !== -1) {
            await saveChat();
          }
          
          // Save chat every 10 chunks
          saveCounter++;
          if (saveCounter % 10 === 0) {
            await saveChat();
          }
        }
        
        // Final save to ensure everything is stored
        await saveChat();
      } catch (error) {
        console.error('Error:', error);
        messages = [...messages, { role: 'assistant', content: `An error occurred: ${error.message}` }];
      } finally {
        isLoading = false;
        await saveChat();
        await tick();
        inputElement.focus();
      }
    }
  }

  async function saveChat() {
    try {
      const response = await fetch('/api/chats', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: chatId,
          messages,
          visible: isVisible,
          title: chatTitle
        })
      });

      if (!response.ok) throw new Error('Failed to save chat');
      console.log('Chat saved successfully');
      
      goto(`/chat/${chatId}`, { replaceState: true });
    } catch (error) {
      console.error('Error saving chat:', error);
    }
  }

  import { createEventDispatcher } from 'svelte';
  import { updateChatVisibility, updateChatTitle, generateTitle, saveNewChat } from '$lib/stores/chatStore';

  const dispatch = createEventDispatcher();

  async function handleVisibilityChange() {
    await saveChat();
    await updateChatVisibility(chatId, isVisible);
    dispatch('visibilityChange', { chatId, isVisible });
  }

  async function changeChatTitle() {
    let newTitle = prompt('Enter new chat title:', chatTitle);
    if (newTitle !== null && newTitle !== chatTitle) {
      if (newTitle.trim() === '') {
        // If the title is empty, generate a new one based on the first user message
        const firstUserMessage = messages.find(m => m.sender === 'user')?.text || '';
        newTitle = await generateTitle(firstUserMessage);
      }
      chatTitle = newTitle;
      await saveChat();
      await updateChatTitle(chatId, chatTitle);
      dispatch('titleChange', { chatId, title: chatTitle });
    }
  }

function splitIntoSentences(text) {
  return text.match(/[^.!?]+[.!?]+/g) || [text];
}

function normalizeText(text) {
  return text.trim().replace(/\s+/g, ' ');
}

function matchesExcerpt(line, matching_sentences) {
  if (!Array.isArray(matching_sentences) || matching_sentences.length === 0) return false;
  
  const normalizedLine = normalizeText(line).replace(/\./g, '');
  if (!normalizedLine) return false;
  
  const sentences = matching_sentences[0].text ? 
    matching_sentences.map(x => normalizeText(x.text).replace(/\./g, '')) :
    matching_sentences.map(s => normalizeText(s).replace(/\./g, ''));
    
  return sentences.some(sentence => {
    const normalizedSentence = normalizeText(sentence).replace(/\./g, '');
    return normalizedLine === normalizedSentence;
  });
}

function highlightMatchingSentences(fullText, matchingSentences) {
  if (!matchingSentences || !fullText) return fullText;
  
  let result = fullText;
  // Sort matching sentences by length (longest first) to avoid nested highlights
  const sortedSentences = [...matchingSentences].sort((a, b) => 
    b.text.length - a.text.length
  );
  
  for (const match of sortedSentences) {
    const text = match.text.trim();
    if (text) {
      // Escape special characters in the text for regex
      const escapedText = text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const regex = new RegExp(`(${escapedText})`, 'g');
      result = result.replace(regex, '<strong>$1</strong>');
    }
  }
  
  return result;
}

</script>

<div class="chat-interface">
  <div class="chat-header">
    <h2>Title: {chatTitle}</h2>
    <button class="edit-title" on:click={changeChatTitle}>✏️</button>
    <label class="switch">
      <input type="checkbox" bind:checked={isVisible} on:change={handleVisibilityChange}>
      <span class="slider round"></span>
    </label>
    <span>{isVisible ? 'Visible' : 'Archived'}</span>
    &nbsp;&nbsp;
    <select 
      bind:value={selectedSource}
      on:change={(e) => setSourceFilterCookie(e.target.value)}
      class="source-select"
    >
      <option value="all">All Sources</option>
      <option value="Tiferet Shlomo">Tiferes Shlomo</option>
      <option value="Divrei Yoel">Divrei Yoel</option>
    </select>
    &nbsp;&nbsp;
    <label class="switch">
      <input 
        type="checkbox" 
        checked={preferredLanguage === 'hebrew'}
        on:change={(e) => {
          preferredLanguage = e.target.checked ? 'hebrew' : 'english';
          setLanguageCookie(preferredLanguage);
        }}
      >
      <span class="slider round"></span>
    </label>
    <span>Preferred Language: {preferredLanguage === 'hebrew' ? 'Hebrew' : 'English'}</span>
  </div>
  <div class="message-list">
    {#if messages.length === 0}
      <div class="message ai">
        <p>No messages yet. Start a conversation by typing a message below!</p>
      </div>
    {:else}
      {#each messages as message}
        <div class="message {message.role === 'user' ? 'user' : 'ai'}">
          {#if message.role === 'user'}
            {@html md.render(`**You:** ${message.content || message.text || ''}`)}
          {:else if message.role === 'assistant' || message.role === 'system'}
            {#if message.context}
              <div class="sources-container">
                  {#each parseSource(message.context, true) as source, index}
                    <div class="source-box">
                      <div class="source-header">
                        <!-- svelte-ignore a11y-click-events-have-key-events -->
                        <!-- svelte-ignore a11y-no-static-element-interactions -->
                        <div class="source-title-row"
                             dir={preferredLanguage === 'hebrew' ? 'rtl' : 'ltr'}
                             on:click={() => {
                               $expandedSources = new Set($expandedSources);
                               if ($expandedSources.has(index)) {
                                 $expandedSources.delete(index);
                               } else {
                                 $expandedSources.add(index);
                               }
                             }}>

							<span class="expand-icon">{$expandedSources.has(index) ? '▼' : (preferredLanguage === 'hebrew') ? '◀':'▶'}</span>
							[{index + 1}]
							<span class="source-title">
							{#if source.sefaria_link}
							<a href={source.sefaria_link} target="_blank" class="source-link" on:click|stopPropagation>
								{#if preferredLanguage === 'hebrew'}{source.name_pretty_hebrew}
								{:else} {source.name_pretty}
								{/if}
							</a>
								{:else}
									{#if preferredLanguage === 'hebrew'}{source.name_pretty_hebrew}
									{:else} {source.name_pretty}
									{/if}
						  		{/if}
							</span>
							{#if source.relevance_score} [{source.relevance_score}/10] {/if}

					</div>

                        <div class="source-conclusion">
						{#if preferredLanguage === 'hebrew'}
                            <h3 class="source-headline" dir="rtl">{source.headline_hebrew}</h3>
							<div dir="rtl"><strong>סיכום דבריו:</strong> {source.conclusion_hebrew}</div>
                          {:else}
                            <h3 class="source-headline">{source.headline_english}</h3>
							<strong>Conclusion: </strong>{source.conclusion_english}
                          {/if}
                        </div>
                      </div>

                      {#if $expandedSources.has(index)}
                        <div class="source-content">
                          {#if source.matching_sentences}
                            <div class="hebrew-text" dir="rtl">
                              {#each source.matching_sentences as text}
                                {text}<br>
                              {/each}
                            </div>
                          {/if}

                          <button 
                            class="show-full-text"
                            on:click={() => {
                              $expandedFullText = new Set($expandedFullText);
                              if ($expandedFullText.has(index)) {
                                $expandedFullText.delete(index);
                              } else {
                                $expandedFullText.add(index);
                              }
                            }}>
                            {$expandedFullText.has(index) ? 'Hide Full Text' : 'Show Full Text'}
                          </button>

                          {#if $expandedFullText.has(index)}
                            <div class="hebrew-text" dir="rtl">
                              {#if source.matching_sentences && source.text}
                                {@const sentences = splitIntoSentences(source.text)}
                                {#each sentences as sentence}
                                  {#if matchesExcerpt(sentence, source.matching_sentences)}
                                    <span class="highlight">{sentence}</span>
                                  {:else}
                                    {sentence}
                                  {/if}
                                {/each}
                              {:else}
                                {source.text}
                              {/if}
                            </div>
                          {/if}
                        </div>
                      {/if}
                    </div>
                  {/each}
                </div>
            {/if}
			<div dir={checkLanguage(message.content || message.text || '')}>
			{@html md.render(message.content || message.text || '')}
		</div>
          {/if}
        </div>
      {/each}
    {/if}
    {#if isLoading}
      <div class="message ai loading">
        <span class="dot"></span>
        <span class="dot"></span>
        <span class="dot"></span>
      </div>
    {/if}
  </div>
  <form on:submit|preventDefault={handleSubmit}>
    <textarea
      bind:value={userInput}
      bind:this={inputElement}
      placeholder="Type your message here... (Shift+Enter for new line, Enter or Ctrl+Enter to send)"
      disabled={isLoading}
      on:keydown={handleKeydown}
      on:input={autoGrow}
      rows="5"
    ></textarea>
    <button type="submit" disabled={isLoading}>
      Send
    </button>
  </form>
</div>

<style>
  .chat-header {
    display: flex;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid #ccc;
  }

  .chat-header h2 {
    margin: 0 10px;
    flex-grow: 1;
  }

  .edit-title {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 1.2em;
    padding: 0;
    margin-right: 10px;
  }

  .new-topic {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin-left: 10px;
    cursor: pointer;
    border-radius: 5px;
  }

  .new-topic:hover {
    background-color: #45a049;
  }

  .chat-interface {
    display: flex;
    flex-direction: column;
    height: 100%;
    flex-grow: 1;
    border: 1px solid #ccc;
    border-radius: 5px;
    overflow: hidden;
  }
  .chat-header {
    display: flex;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid #ccc;
  }
  .chat-header h2 {
    margin-right: 20px;
  }
  .message-list {
    flex-grow: 1;
    overflow-y: auto;
    padding: 10px;
    word-wrap: break-word;
    overflow-x: hidden;
  }
  .message {
    margin-bottom: 10px;
    padding: 8px 12px;
    border-radius: 8px;
    font-family: 'Arial', sans-serif;
    font-size: 16px;
    line-height: 1.4;
  }
  .message :global(p) {
    margin: 0 0 10px 0;
    white-space: pre-wrap;
  }
  .message :global(ul), .message :global(ol) {
    margin: 0 0 10px 0;
    padding-left: 30px;
  }
  .message :global(strong) {
    font-weight: bold;
  }
  .message :global(em) {
    font-style: italic;
  }
  .user {
    background-color: #e6f2ff;
    align-self: flex-end;
  }
  .ai {
    background-color: #f0f0f0;
    align-self: flex-start;
  }
  form {
    display: flex;
    padding: 10px;
  }
  textarea {
    flex-grow: 1;
    padding: 5px;
    margin-right: 10px;
    resize: none;
    min-height: 80px;
    height: 80px;
    max-height: 200px;
    overflow-y: auto;
  }
  button {
    padding: 5px 10px;
    align-self: stretch;
    min-height: 50px;
    width: 80px;
  }
  .loading {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .dot {
    width: 8px;
    height: 8px;
    background-color: #333;
    border-radius: 50%;
    margin: 0 4px;
    animation: pulse 1.5s infinite ease-in-out;
  }
  .dot:nth-child(2) {
    animation-delay: 0.5s;
  }
  .dot:nth-child(3) {
    animation-delay: 1s;
  }
  @keyframes pulse {
    0%, 100% {
      transform: scale(0.8);
      opacity: 0.5;
    }
    50% {
      transform: scale(1.2);
      opacity: 1;
    }
  }
  .switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
    margin-right: 10px;
  }
  .switch input {
    opacity: 0;
    width: 0;
    height: 0;
  }
  .slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
  }
  .slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: .4s;
  }
  input:checked + .slider {
    background-color: #2196F3;
  }
  input:focus + .slider {
    box-shadow: 0 0 1px #2196F3;
  }
  input:checked + .slider:before {
    transform: translateX(26px);
  }
  .slider.round {
    border-radius: 34px;
  }
  .slider.round:before {
    border-radius: 50%;
  }
  
  .source-select {
    padding: 5px 10px;
    margin: 0 10px;
    border-radius: 4px;
    border: 1px solid #ccc;
    background-color: white;
    cursor: pointer;
  }
  
  .source-select:hover {
    border-color: #2196F3;
  }
  
  .sources-container {
    margin: 5px auto;
    padding-top: 5px;
    max-width: 850px;
    width: 100%;
  }

  .sources-container h4 {
    margin-top: 0;
    margin-bottom: 3px;
    color: #333;
  }

  .source-box {
    margin-bottom: 8px;
    background-color: #f9f9f9;
    border: 1px solid #d0cfcf;
    border-radius: 8px;
    padding: 8px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    transition: all 0.3s ease;
  }

  .source-box:hover {
    box-shadow: 0 4px 6px rgba(0,0,0,0.15);
  }

  .source-header {
    display: flex;
    flex-direction: column;
    gap: 4px;
  }

  .source-title-row {
	font-size: .8em;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 5px;
    padding: 2px;
    user-select: none;
  }

  .source-title-row:hover {
    background-color: rgba(0, 0, 0, 0.05);
    border-radius: 4px;
  }

  .expand-icon {
    font-size: 0.8em;
    color: #666;
    margin-right: 5px;
    pointer-events: none;
  }

  .source-conclusion {
    font-size: 1.1em;
    margin: 0;
    padding-left: 20px;
  }

  .source-headline {
    margin: 0 0 4px 0;
    font-size: 1.1em;
  }

  .source-content {
    margin-top: 8px;
    padding-top: 8px;
    border-top: 1px solid #eee;
  }

  .show-full-text {
    display: block;
    width: 100%;
    padding: 8px;
    margin: 10px 0;
    background-color: #f0f0f0;
    border: 1px solid #ddd;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }

  .show-full-text:hover {
    background-color: #e0e0e0;
  }

  .source-title {
    margin: 0;
    padding: 3px;
    #border-bottom: 2px solid #3498db;
    border-radius: 4px;
	background-color: #ebe692;
  }

  .source-tags, .source-context {
    font-size: 0.9em;
    color: #555;
  }

  .source-link {
    display: inline-block;
    color: #3498db;
    text-decoration: none;
    font-weight: bold;
    margin-top: 5px;
    transition: color 0.3s ease;
  }

  .source-link:hover {
    color: #2980b9;
    text-decoration: underline;
  }

  .hebrew-text {
    font-family: 'David Libre', serif;
    font-size: 1.4em;
    line-height: 1.4;
    margin-top: 8px;
    padding: 8px;
    background-color: #fff;
    border: 1px solid #e0e0e0;
    border-radius: 4px;
    box-shadow: inset 0 1px 3px rgba(0,0,0,0.1);
  }

  .highlight {
    background-color: #fff3cd;
    padding: 2px 4px;
    border-radius: 3px;
    display: inline-block;
  }


</style>

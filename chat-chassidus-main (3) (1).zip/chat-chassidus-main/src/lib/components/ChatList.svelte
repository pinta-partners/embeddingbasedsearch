<script>
  import { onMount, createEventDispatcher } from 'svelte';
  import { chats, loadChats, updateChatVisibility, updateChatTitle, createNewChat } from '$lib/stores/chatStore';
  import { goto } from '$app/navigation';
  import { page } from '$app/stores';

  export let selectedChatId = null;

  const dispatch = createEventDispatcher();

  $: selectedChatId = $page.params.id;

  onMount(() => {
    loadChats();
  });

  function startNewChat() {
    const { id: newChatId, title: newChatTitle } = createNewChat();
    dispatch('chatSelect', { id: 'new', title: newChatTitle, isNew: true });
    goto('/chat/new');
  }

  export function handleVisibilityChange(chatId, isVisible) {
    updateChatVisibility(chatId, isVisible);
  }

  export function handleTitleChange(chatId, newTitle) {
    updateChatTitle(chatId, newTitle);
  }
</script>

<div class="chat-list">
  <h2>Your Topics</h2>
  <center><button on:click={startNewChat}>New Topic</button></center>
  <ul>
    {#each $chats as chat}
      <li class:selected={chat.id === selectedChatId}>
        <a href="/chat/{chat.id}" class="chat-btn" data-sveltekit-preload-data="hover">
          {chat.title}
        </a>
      </li>
    {/each}
  </ul>
</div>

<style>
  .selected {
    background-color: #b0b0b0;
  }
  .chat-list {
    width: 250px;
    min-width: 250px;
    height: 100%;
    overflow-y: auto;
    border-right: 1px solid #ccc;
    padding: 20px;
  }
  ul {
    list-style-type: none;
    padding: 0;
  }
  li {
    margin-bottom: 10px;
    display: flex;
    align-items: center;
  }
  .chat-btn {
    background: none;
    border: none;
    cursor: pointer;
    text-align: left;
    color: #333;
    margin-left: 10px;
    padding: 5px;
    width: 100%;
    display: block;
    text-decoration: none;
  }
  .chat-btn:hover {
    background-color: #f0f0f0;
  }
</style>

-- Enable pgvector extension for vector operations
CREATE EXTENSION IF NOT EXISTS vector;

-- Create chats table
CREATE TABLE chats (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id INTEGER,
    title TEXT NOT NULL,
	archived BOOLEAN DEFAULT FALSE,
    messages JSONB NOT NULL,
    is_shared BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create chassidus_texts table
CREATE TABLE chassidus_texts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    text TEXT NOT NULL,
    embedding VECTOR(1536),
    source TEXT NOT NULL,
    tags TEXT[],
    sefaria_name TEXT,
    paragraph TEXT,
    translation TEXT,
	translation_version INTEGER,
    context TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create function to update updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create trigger to update updated_at column for chats table
CREATE TRIGGER update_chats_updated_at
BEFORE UPDATE ON chats
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- Create trigger to update updated_at column for chassidus_texts table
CREATE TRIGGER update_chassidus_texts_updated_at
BEFORE UPDATE ON chassidus_texts
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();


-- Create function for similarity search
create or replace function match_documents(
   query_embedding vector(1536),
   match_threshold float,
   match_count int
 )

 RETURNS TABLE (
    id UUID,
    text TEXT,
	context TEXT,
	translation TEXT,
    source TEXT,
    tags TEXT[],
    sefaria_name TEXT,
    paragraph TEXT,
    similarity FLOAT
)
 language plpgsql
 as $$
 begin
   return query
   select
     ct.id,
     ct.text,
     ct.context,
     ct.translation,
     ct.source,
     ct.tags,
     ct.sefaria_name,
     ct.paragraph,
     1 - (ct.embedding_context <=> query_embedding) as similarity
   from chassidus_texts ct
   where 1 - (ct.embedding_context <=> query_embedding) > match_threshold
   order by ct.embedding_context <=> query_embedding
   limit match_count;
 end;
 $$;
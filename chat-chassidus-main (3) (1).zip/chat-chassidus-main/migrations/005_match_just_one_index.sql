CREATE OR REPLACE FUNCTION match_documents_chunks_context(
    query_embedding VECTOR(1536),
    match_threshold FLOAT,
    match_count INT
)
RETURNS TABLE (
    id UUID,
	chassidus_text_id UUID,
    sentence TEXT,
    sentence_number INTEGER,
    context TEXT,
    paragraph TEXT,
    full_paragraph TEXT,
    translation TEXT,
    source TEXT,
    tags TEXT[],
    sefaria_name TEXT,
    similarity FLOAT
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT
        cs.id,
		cs.chassidus_text_id,
        cs.sentence,
        cs.sentence_number,
        ct.context,
        cs.paragraph,
        ct.text AS full_paragraph,
        ct.translation,
        cs.source,
        cs.tags,
        cs.sefaria_name,
        1 - (cs.embedding_sentence_with_context <=> query_embedding) AS similarity
    FROM chassidus_sentences cs
    JOIN chassidus_texts ct ON cs.chassidus_text_id = ct.id
    WHERE 1 - (cs.embedding_sentence_with_context <=> query_embedding) > match_threshold
    ORDER BY similarity DESC
    LIMIT match_count;
END;
$$;





CREATE OR REPLACE FUNCTION match_documents_chunks_nocontext(
    query_embedding VECTOR(1536),
    match_threshold FLOAT,
    match_count INT
)
RETURNS TABLE (
    id UUID,
	chassidus_text_id UUID,
    sentence TEXT,
    sentence_number INTEGER,
    context TEXT,
    paragraph TEXT,
    full_paragraph TEXT,
    translation TEXT,
    source TEXT,
    tags TEXT[],
    sefaria_name TEXT,
    similarity FLOAT
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    SELECT
        cs.id,
		cs.chassidus_text_id,
        cs.sentence,
        cs.sentence_number,
        ct.context,
        cs.paragraph,
        ct.text AS full_paragraph,
        ct.translation,
        cs.source,
        cs.tags,
        cs.sefaria_name,
        1 - (cs.embedding_sentence <=> query_embedding) AS similarity
    FROM chassidus_sentences cs
    JOIN chassidus_texts ct ON cs.chassidus_text_id = ct.id
    WHERE 1 - (cs.embedding_sentence <=> query_embedding) > match_threshold
    ORDER BY similarity DESC
    LIMIT match_count;
END;
$$;

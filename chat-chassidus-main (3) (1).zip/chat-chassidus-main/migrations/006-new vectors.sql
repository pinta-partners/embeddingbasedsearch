Table: chassidus_sentences
Select data Show structure Alter table New item

Column	Type	Comment
id	uuid [uuid_generate_v4()]	
chassidus_text_id	uuid NULL	
sentence	text	
sentence_number	integer	
context	text NULL	
paragraph	text	
embedding_large_context_hebrew	vector(1536) NULL	
embedding_jina_context_hebrew	vector(1024) NULL	
source	text	
tags	text[] NULL	
sefaria_name	text NULL	
created_at	timestamptz NULL [CURRENT_TIMESTAMP]	
updated_at	timestamptz NULL [CURRENT_TIMESTAMP]	
translation	text NULL	
translation_version	integer NULL	
embedding_small_context_english	vector(1536) NULL	
embedding_large_context_english	vector(3072) NULL	
embedding_jina_context_english	vector(1024) NULL

alter table chassidus_sentences
add column embedding_large_english vector(3072),
add column embedding_large_english_hebrew vector(3072),
add column embedding_small_english vector(1536),
add column embedding_small_english_hebrew vector(1536)
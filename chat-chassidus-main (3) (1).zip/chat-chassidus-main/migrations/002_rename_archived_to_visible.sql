-- Rename the 'archived' column to 'visible' and invert its meaning
ALTER TABLE chats RENAME COLUMN archived TO visible;

-- Invert the boolean value for all existing rows
UPDATE chats SET visible = NOT visible;

-- Set the default value for the 'visible' column to true
ALTER TABLE chats ALTER COLUMN visible SET DEFAULT true;

create index on "public"."chassidus_sentences" using hnsw (embedding_sentence vector_cosine_ops);
create index on "public"."chassidus_sentences" using hnsw (embedding_sentence_with_context vector_cosine_ops);

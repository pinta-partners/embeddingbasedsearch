CREATE TABLE chassidus_sentences (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    chassidus_text_id UUID REFERENCES chassidus_texts(id),
    sentence TEXT NOT NULL,
    sentence_number INTEGER NOT NULL,
    context TEXT,
    paragraph TEXT NOT NULL,
    embedding_sentence VECTOR(1536),
    embedding_sentence_with_context VECTOR(1536),
    source TEXT NOT NULL,
    tags TEXT[],
    sefaria_name TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create trigger to update updated_at column for chassidus_sentences table
CREATE TRIGGER update_chassidus_sentences_updated_at
BEFORE UPDATE ON chassidus_sentences
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();


CREATE OR REPLACE FUNCTION match_documents_chunks(
    query_embedding VECTOR(1536),
    match_threshold FLOAT,
    match_count INT
)
RETURNS TABLE (
    id UUID,
    sentence TEXT,
    sentence_number INTEGER,
    context TEXT,
    paragraph TEXT,
    full_paragraph TEXT,
    translation TEXT,
    source TEXT,
    tags TEXT[],
    sefaria_name TEXT,
    similarity_sentence FLOAT,
    similarity_sentence_with_context FLOAT,
    best_similarity FLOAT
)
LANGUAGE plpgsql
AS $$
BEGIN
    RETURN QUERY
    WITH similarities AS (
        SELECT
            cs.id,
            cs.sentence,
            cs.sentence_number,
            ct.context as context,
            cs.paragraph,
            ct.text AS full_paragraph,
            ct.translation,
            cs.source,
            cs.tags,
            cs.sefaria_name,
            1 - (cs.embedding_sentence <=> query_embedding) AS similarity_sentence,
            1 - (cs.embedding_sentence_with_context <=> query_embedding) AS similarity_sentence_with_context
        FROM chassidus_sentences cs
        JOIN chassidus_texts ct ON cs.chassidus_text_id = ct.id
    )
    SELECT
        s.id,
        s.sentence,
        s.sentence_number,
        s.context,
        s.paragraph,
        s.full_paragraph,
        s.translation,
        s.source,
        s.tags,
        s.sefaria_name,
        s.similarity_sentence,
        s.similarity_sentence_with_context,
        GREATEST(s.similarity_sentence, s.similarity_sentence_with_context) AS best_similarity
    FROM similarities s
    WHERE GREATEST(s.similarity_sentence, s.similarity_sentence_with_context) > match_threshold
    ORDER BY best_similarity DESC
    LIMIT match_count;
END;
$$;

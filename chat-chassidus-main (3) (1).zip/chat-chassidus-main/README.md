#Contact Persons:
- chezkyk@pintapartners.com
- CC jason: jpaul@pintapartners.com 


# Local Setup to run search benchmark

## Clone the repository: 
`git clone https://github.com/BestFone/chat-chassidus.git`

## VPN: zerotier
- https://www.zerotier.com/download/
- Request to join network: 0cccb752f7a89132
- Ask for approval

## Install dependencies
- nodejs: https://nodejs.org/en/download/package-manager
- other deps: `npm install`

## Add credentials
- Create a file called `.env` in the root directory of the project, with the following lines:
  - OPENAI_API_KEY=<your_openai_api_key>
  - CLAUDE_API_KEY=<your_claude_api_key>
  - POSTGRES_URL=postgres://postgres:\$\$PASSWORD\$\$@192.168.191.210/chassidus
  
## Check the Benchmark Data
- `sources/tiferes_shlomo_test_data.json`

## Run the benchmark
`node src/lib/embeddingUtils.test.js` 



# create-svelte

Everything you need to build a Svelte project, powered by [`create-svelte`](https://github.com/sveltejs/kit/tree/main/packages/create-svelte).

## Creating a project

If you're seeing this, you've probably already done this step. Congrats!

```bash
# create a new project in the current directory
npm create svelte@latest

# create a new project in my-app
npm create svelte@latest my-app
```

## Developing

Once you've created a project and installed dependencies with `npm install` (or `pnpm install` or `yarn`), start a development server:

```bash
npm run dev

# or start the server and open the app in a new browser tab
npm run dev -- --open
```

## Building

To create a production version of your app:

```bash
npm run build
```

You can preview the production build with `npm run preview`.

> To deploy your app, you may need to install an [adapter](https://kit.svelte.dev/docs/adapters) for your target environment.

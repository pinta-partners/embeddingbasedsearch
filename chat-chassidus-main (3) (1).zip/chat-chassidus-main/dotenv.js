import dotenv from 'dotenv';
const __dirname = import.meta.dirname;
import {join} from 'path';
console.log(__dirname)
dotenv.config({path: join(__dirname,'.env')});

export default process.env;
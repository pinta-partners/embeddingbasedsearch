#=================PGSQL with vectors:

# Update package list
sudo apt update

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib postgresql-server-dev-all

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Install build dependencies
sudo apt install git gcc make libssl-dev libreadline-dev zlib1g-dev

# Clone pg_vector
git clone --branch v0.7.4 https://github.com/pgvector/pgvector.git
cd pgvector
# Build and install pg_vector
make
sudo make install

# Add pg_vector to shared_preload_libraries
sudo sed -i "s/#shared_preload_libraries = ''/shared_preload_libraries = 'vector'/g" /etc/postgresql/*/main/postgresql.conf

# Restart PostgreSQL
sudo systemctl restart postgresql

# Create a new database and enable the extension
sudo -u postgres psql
CREATE DATABASE chassidus;
\c chassidus
CREATE EXTENSION vector;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
ALTER USER postgres WITH PASSWORD '$$your_secure_password';
\q

#create user: read all, and write to `chats`
sudo -u postgres psql
\c chassidus
CREATE USER chassidus_user WITH PASSWORD '8uLFxKY8Xsg7';
GRANT SELECT ON ALL TABLES IN SCHEMA public TO chassidus_user;
GRANT INSERT, UPDATE ON chats TO chassidus_user;
GRANT INSERT, UPDATE ON embedding_cache TO chassidus_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public 
    GRANT SELECT ON TABLES TO chassidus_user;


#====================Zeroties for VPN
#https://my.zerotier.com/network/0cccb752f7a89132

# Install ZeroTier
curl -s https://install.zerotier.com | sudo bash

# Join your ZeroTier network (replace NETWORK_ID with your actual network ID)
sudo zerotier-cli join 0cccb752f7a89132

#get your IP and mask:
sudo zerotier-cli listnetworks

# Configure PostgreSQL to listen on ZeroTier IP
sudo nano /etc/postgresql/*/main/postgresql.conf
# Add or modify this line:
# listen_addresses = 'localhost,ZEROTIER_IP'

# Configure PostgreSQL to allow connections from ZeroTier network
sudo nano /etc/postgresql/*/main/pg_hba.conf
# Add this line (replace ZEROTIER_NETWORK with your network, e.g., 192.168.195.0/24):
# host    all    all    192.168.191.210/24    scram-sha-256

# Restart PostgreSQL
sudo systemctl restart postgresql


#-------------------Github deploy
# Generate SSH key
ssh-keygen -t ed25519 -C "marcus@bestfone.com"

# Display the public key
cat ~/.ssh/id_ed25519.pub

# Copy the output and add it as a deploy key in your GitHub repository settings
#https://github.com/BestFone/chat-chassidus/settings/keys

# Clone your repository
cd /root && git clone git@github.com:BestFone/chat-chassidus.git
#create .env file with paths
nano chat-chassidus/.env

# Install Node.js and npm
curl -fsSL https://deb.nodesource.com/setup_lts.x | sudo -E bash -
sudo apt-get install -y nodejs

# Navigate to your project directory
cd chat-chassidus

# Install dependencies
npm install

# Build your Vite/SvelteKit project
npm run build

# To run the development server
npm run dev


